const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('app/src/main/assets/index.html', 'utf8');
const scripts = [...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(x => x[1]);
assert.equal(scripts.length, 1, 'Expected one inline application script');
new vm.Script(scripts[0], { filename: 'index.html:inline-script' });
assert.equal((html.match(/id=\\"incomeOwnedTime\\"/g) || []).length, 1, 'Income ownership time input must exist exactly once');
assert.equal((html.match(/id=\\"incomeOwnedDate\\"/g) || []).length, 1, 'Income ownership date input must exist exactly once');
assert(!html.includes('<input <div'), 'Malformed ownership-time input markup remains');
assert(html.includes("درآمد ثبت‌شده (خارج از جمع قطعی تا تعیین دوره)"), 'Income must remain outside the unallocated annual base');
assert(html.includes('هزینه به درآمد و دوره خمسی مشخص متصل نشده است'), 'Unallocated expenses must not be deducted');
assert(html.includes('preliminaryIncomePeriod||y.result.audit.paymentBlocked'), 'Installments must be blocked for preliminary or unresolved results');
const gradle = fs.readFileSync('app/build.gradle', 'utf8');
assert(gradle.includes("versionCode 65; versionName '2.38.19'"), 'Android version metadata mismatch');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
assert.equal(pkg.version, '2.38.19');
assert.equal(pkg.main, 'desktop/main.cjs');
assert(fs.existsSync('.github/workflows/build-from-archive.yml'));
const workflow = fs.readFileSync('.github/workflows/build-from-archive.yml', 'utf8');
assert(workflow.includes('khoms-v2.38.19-source.zip'), 'Workflow archive name mismatch');
assert(workflow.includes('android:') && workflow.includes('windows:'), 'Canonical workflow must build both platforms');
assert(workflow.includes('workflow_dispatch:'), 'Canonical workflow must support manual start');
assert(workflow.includes("paths:\n      - 'khoms-v2.38.19-source.zip'"), 'Build must wait for the matching source archive');
assert(fs.readFileSync('android/app/build.gradle','utf8').includes("versionCode 65; versionName '2.38.19'"), 'Active Android Gradle project metadata mismatch');
assert(fs.readFileSync('android/app/build.gradle','utf8').includes("res.srcDirs = ['../../app/src/main/res']"), 'Android launcher resources must be included in the active module');
assert(fs.existsSync('app/src/main/res/drawable/ic_launcher.xml'), 'Android launcher icon resource missing');
assert(fs.readFileSync('desktop/main.cjs','utf8').includes("'assets', 'index.html'"), 'Desktop app must load the shared offline interface');
assert(workflow.includes('--publish never'), 'Windows CI must not attempt automatic publishing');
assert(html.includes('calculationActive = /سیستانی/.test(y.marja)'), 'Non-Sistani records must be enabled without enabling unverified calculation');
assert(html.includes('var lines = [], specialLines = [], base = 0, specialBase = 0, excluded = [], warnings = [], deductionTotal = 0, unresolvedReviews = [];'), 'Unresolved review ledger must be initialized');
assert(html.includes('unresolvedReviewCount: unresolvedReviews.length') && html.includes('paymentBlocked: hasIncomeItems || unresolvedReviews.length > 0 || incomeLedger.unresolved.length > 0'), 'Calculation audit must block payment when unresolved items remain');
assert(html.includes('function khomsBuildIncomeLedger(y, items)') && html.includes('calculationApplied:false'), 'Income ledger must remain informational and separate from tax calculation');
assert(html.includes('function expenseIncomeLinkOptions(y,selected)') && html.includes('id=\"expenseIncomeLink\"'), 'Expense-to-income selector must be present');
assert(html.includes('linkedIncomeId:') && html.includes('item.linkedIncomeId||'), 'Expense-to-income link must persist and be editable');
assert(html.includes('group.expenseTotal+=') && html.includes('deductionApplied:false'), 'Linked expenses must be grouped and audited without being deducted');
assert(html.includes('incomeLedgerUnresolvedCount: incomeLedger.unresolved.length') && html.includes('دفتر درآمد و هزینه و دوره‌ها'), 'Income ledger must be included in audit and visible in results');
assert(html.includes("if (d.status === 'review')"), 'Review status must be tracked rather than silently ignored');
assert(html.includes('audit.paymentBlocked||Number(y.result.audit.unresolvedReviewCount)>0'), 'Cash/installment payment must be blocked for unresolved reviews');
assert(html.includes('function createInstallments()'), 'Installment creation action must exist');
assert(html.includes('function marjaProfilePage(el)') && html.includes('openNewYearForMarja'), 'Each marja profile must open a dedicated data workspace');
assert(html.includes('debt_for_expense:') && html.includes("value) === 'yes'"), 'Debt expense condition must store an explicit yes/no answer');
assert(html.includes('function registerCashPayment()'), 'Cash payment and receipt action must exist');
assert(html.includes('window.AndroidKhoms.startSpeech'), 'Android native voice bridge must be connected');
assert(html.includes('function currentDateInCalendar'), 'Calendar-aware date helper must exist');
assert(html.includes('localStorage.getItem(KEY)!==serialized'), 'Save operation must verify read-back persistence');
assert(html.includes('ystartToday') && html.includes('toggleYearStartMode'), 'New fiscal year date must default automatically from selected calendar');
assert(html.includes('handleYearCalendarChange') && html.includes('handleEditYearCalendarChange'), 'Changing the selected calendar must prevent misreading an old date');
assert(html.includes('ystartToday') && html.includes('toggleYearStartMode'), 'New fiscal year date must default automatically from selected calendar');
assert(html.includes("type==='business_expense'"), 'Business expense rule lookup must be handled');
assert(html.includes("l.rule ? l.rule.title : 'نیازمند بررسی'"), 'Result renderer must tolerate rule-less lines');
const manifest = fs.readFileSync('app/src/main/AndroidManifest.xml', 'utf8');
assert(manifest.includes('android.permission.RECORD_AUDIO'), 'Microphone permission missing');
assert(manifest.includes('android:icon="@drawable/ic_launcher"'), 'Custom app launcher icon missing');
assert(fs.existsSync('app/src/main/res/drawable/ic_launcher.xml'), 'Launcher icon vector missing');
const activity = fs.readFileSync('app/src/main/java/ir/khoms/app/MainActivity.java', 'utf8');
assert(activity.includes('addJavascriptInterface(new VoiceBridge(), "AndroidKhoms")'), 'Native voice bridge missing');
assert(activity.includes('SpeechRecognizer.createOnDeviceSpeechRecognizer'), 'On-device speech recognition preference missing');
assert(activity.includes('printHtml(String html)') && activity.includes('createPrintDocumentAdapter'), 'Native Android receipt printing bridge missing');
assert(html.includes('AndroidKhoms.printHtml'), 'Receipt printing must use the native Android print bridge when available');

assert(html.includes('if(!save()){db.people.pop();return;}'), 'New profile must not navigate after failed persistence');
assert(html.includes('if(!save()){Object.assign(p,before);return;}'), 'Profile edit must rollback on failed persistence');
assert(html.includes('if(!save()){y.items=previousItems;y.result=previousResult;y.status=previousStatus;editingItemId=wasEditing;return;}'), 'Financial item edit/add must rollback on failed persistence');
assert(html.includes('function deleteItem(itemId)') && html.includes('if(!save()){y.items=oldItems;y.result=oldResult;y.status=oldStatus;return;}'), 'Item deletion must rollback on failed persistence');
assert(html.includes('var previousResult=y.result, previousStatus=y.status;'), 'Calculation result must not pretend to persist after a storage failure');
assert(html.includes('debt_for_expense:') && html.includes("value) === 'yes'"), 'Debt expense condition must be stored as an explicit yes/no value');


// Regression test: a Khamenei fiscal year must be stored and navigate to its own year page.
function makeElementMap(values = {}) {
  const map = new Map();
  return { getElementById(id) {
    if (!map.has(id)) map.set(id, { value: values[id] ?? '', checked: false, type: 'text', style: {}, classList: { add() {}, remove() {} }, focus() {}, closest() { return { style: {} }; } });
    return map.get(id);
  }};
}
const addYearStart = html.indexOf('function addYear()');
const addYearEnd = html.indexOf('\nfunction editYearPage', addYearStart);
const addYearSource = html.slice(addYearStart, addYearEnd);
const yearRecord = { years: [] };
const yearState = { personId: 'person-1', page: 'newyear' };
const yearContext = {
  db: { people: [{ id: 'person-1', years: yearRecord.years }] }, state: yearState,
  document: makeElementMap({ ym: 'آیت‌الله خامنه‌ای', yt: '۱۴۰۵', yc: 'شمسی', yd: '۱۴۰۵/۰۹/۰۶', yfp: 'unknown', ywt: '09:00' }),
  khomsParseCalendarDate: () => ({ ok: true, iso: '2026-11-27' }), id: () => 'year-1', save: () => true, app() {}, nav() {}
};
vm.runInNewContext(addYearSource + '\naddYear();', yearContext);
assert.equal(yearRecord.years.length, 1, 'Khamenei year must be saved');
assert.equal(yearRecord.years[0].marja, 'آیت‌الله خامنه‌ای', 'Khamenei year must retain its own marja');
assert.equal(yearContext.state.page, 'year', 'After successful year creation, the app must navigate to that year');

// Regression test: an income item can be added, and a failed save must roll back the in-memory item.
const addItemStart = html.indexOf('function addItem()');
const addItemEnd = html.indexOf('\nfunction calcYear()', addItemStart);
const addItemSource = html.slice(addItemStart, addItemEnd);
function runAddItem(saveResult) {
  const y = { id: 'year-1', calendar: 'میلادی', items: [], result: null, status: 'old' };
  const p = { id: 'person-1', years: [y] };
  const els = makeElementMap({ it: 'income', ia: '100000', iv: '0', in: 'حقوق', incomeOwnedDate: '2026/11/27', incomeKind: 'business', incomeBusinessLine: 'کارمندی' });
  const ctx = { document: els, state: { personId: p.id, yearId: y.id }, db: { people: [p] }, validateRequiredItemFields: () => true, khomsParseCalendarDate: () => ({ ok: true, iso: '2026-11-27' }), id: () => 'item-1', save: () => saveResult, app() {}, editingItemId: null, Number, Math, Date, JSON };
  vm.runInNewContext(addItemSource + '\naddItem();', ctx);
  return y;
}
assert.equal(runAddItem(true).items.length, 1, 'Income item should be recorded');
assert.equal(runAddItem(false).items.length, 0, 'Income item must roll back if storage fails');

// Conditional-field validation must reject an unanswered debt condition, but accept explicit yes/no answers.
const validationStart = html.indexOf('function validateRequiredItemFields(type)');
const validationEnd = html.indexOf('\n\nfunction addItem()', validationStart);
const validationSource = html.slice(validationStart, validationEnd);
function checkDebtAnswer(answer) {
  const els = makeElementMap({ m_debt_amount: '250000', m_debt_expense: answer });
  const alerts = [];
  const ctx = { document: { getElementById: els.getElementById, querySelectorAll: () => [] }, alert: msg => alerts.push(msg) };
  return { result: vm.runInNewContext(validationSource + '\nvalidateRequiredItemFields(\"debt\");', ctx), alerts };
}
assert.equal(checkDebtAnswer('').result, false, 'Unanswered debt condition must block saving');
assert.equal(checkDebtAnswer('yes').result, true, 'Explicit yes must pass required-field validation');
assert.equal(checkDebtAnswer('no').result, true, 'Explicit no must pass required-field validation');

// Calendar and Persian voice-number parsers are checked with representative user inputs.
const calendarStart = html.indexOf('function khomsCalendarParts(');
const calendarEnd = html.indexOf('\nfunction khomsValidateCalendarDate', calendarStart);
const calendarSource = html.slice(calendarStart, calendarEnd);
const calendarContext = { Intl, Date, Math, String, Number };
vm.runInNewContext(calendarSource + '\nthis.parsed = khomsParseCalendarDate(\"1405/09/06\", \"شمسی\");', calendarContext);
assert.equal(calendarContext.parsed.ok, true, 'Selected-calendar date must parse');
assert.equal(calendarContext.parsed.iso, '2026-11-27', 'Persian calendar date must normalize consistently');
const voiceStart = html.indexOf('function parsePersianSpokenNumber(');
const voiceEnd = html.indexOf('\nwindow.onKhomsSpeechResult', voiceStart);
const voiceSource = html.slice(voiceStart, voiceEnd);
const voiceContext = { String, Number };
vm.runInNewContext(voiceSource + '\nthis.parsed = parsePersianSpokenNumber(\"سه میلیون و پانصد هزار تومان\");', voiceContext);
assert.equal(voiceContext.parsed, 3500000, 'Persian spoken amount must parse correctly');



// Regression tests for the new informational income/expense ledger.
const ledgerStart = html.indexOf('function khomsAuditDebtPurchaseRule(item)');
const ledgerEnd = html.indexOf('\nfunction currentDateInCalendar', ledgerStart);
const ledgerSource = html.slice(ledgerStart, ledgerEnd);
const decisionStart = html.indexOf('var DECISION_RULES = {');
const decisionEnd = html.indexOf('function decisionFor(', decisionStart);
const decisionSource = html.slice(decisionStart, decisionEnd);
const claimCases = [
  {name:'income receivable collectible on demand is taxable at recorded value',meta:{claim_is_income:true,claim_collectible_now:true,claim_cash_value:1250000},status:'taxable',base:1250000},
  {name:'income receivable not collectible and defer selected',meta:{claim_is_income:true,claim_collectible_now:false,claim_method:'defer'},status:'deferred_receivable'},
  {name:'income receivable cash settlement uses current cash value',meta:{claim_is_income:true,claim_collectible_now:false,claim_method:'cash',claim_cash_value:1000000},status:'taxable',base:1000000},
  {name:'income receivable missing cash value cannot calculate',meta:{claim_is_income:true,claim_collectible_now:true,claim_cash_value:0},status:'review'},
  {name:'non-income receivable from taxed funds is excluded',meta:{claim_is_income:false},status:'excluded'},
  {name:'claim issue 716 matured-income loan exception',meta:{claim_is_income:false,claim_matured_income_lent_to_shia:true},status:'immediate_payment_review'}
];
for (const c of claimCases) {
  const ctx={Number,Math,String};
  vm.runInNewContext(decisionSource+'\nthis.out=DECISION_RULES.claim.decide('+JSON.stringify(c.meta)+');',ctx);
  assert.equal(ctx.out.status,c.status,'Claim audit failed: '+c.name);
  if(c.base!==undefined) assert.equal(ctx.out.base,c.base,'Claim value base failed: '+c.name);
}

const expenseAuditCases = [
  {name:'issue 712 non-muana asset with debt repaid from current income',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'non_mouna',expense_debt_purchase_method:'loan',expense_debt_purchase_total_debt:'10000000',expense_debt_purchase_cumulative_paid:'2500000',expense_debt_purchase_prior_recognized_percent:'0',expense_debt_purchase_asset_exists:'yes',expense_debt_purchase_used_in_muana:'no',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income'},expected:'non_mouna_asset_debt_paid_712_review'},
  {name:'issue 713 garden with no debt paid by year end',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'garden_shop',expense_debt_purchase_method:'credit',expense_debt_purchase_total_debt:'20000000',expense_debt_purchase_cumulative_paid:'0',expense_debt_purchase_prior_recognized_percent:'0',expense_debt_purchase_asset_exists:'yes',expense_debt_purchase_used_in_muana:'no',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income'},expected:'garden_shop_unpaid_debt_713_review'},
  {name:'issue 713 partial debt repayment records proportional share only',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'garden_shop',expense_debt_purchase_method:'loan',expense_debt_purchase_total_debt:'12000000',expense_debt_purchase_cumulative_paid:'6000000',expense_debt_purchase_prior_recognized_percent:'25',expense_debt_purchase_asset_exists:'yes',expense_debt_purchase_used_in_muana:'no',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income'},expected:'garden_shop_partial_or_full_payment_713_review'},
  {name:'issue 713 unpaid trading asset flags appreciation separately',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'garden_shop',expense_debt_purchase_method:'loan',expense_debt_purchase_total_debt:'12000000',expense_debt_purchase_cumulative_paid:'0',expense_debt_purchase_prior_recognized_percent:'0',expense_debt_purchase_asset_exists:'yes',expense_debt_purchase_used_in_muana:'no',expense_debt_purchase_is_trade:'yes',expense_debt_purchase_repayment_source:'current_income'},expected:'garden_shop_unpaid_debt_713_review'},
  {name:'issue 712 asset destroyed during the year uses the specific exception review',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'non_mouna',expense_debt_purchase_method:'loan',expense_debt_purchase_total_debt:'10000000',expense_debt_purchase_cumulative_paid:'2500000',expense_debt_purchase_prior_recognized_percent:'0',expense_debt_purchase_asset_exists:'destroyed',expense_debt_purchase_used_in_muana:'no',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income'},expected:'non_mouna_asset_destroyed_or_used'},
  {name:'sold asset is not conflated with destruction',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'non_mouna',expense_debt_purchase_method:'loan',expense_debt_purchase_total_debt:'10000000',expense_debt_purchase_cumulative_paid:'2500000',expense_debt_purchase_prior_recognized_percent:'0',expense_debt_purchase_asset_exists:'sold',expense_debt_purchase_used_in_muana:'no',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income'},expected:'non_mouna_asset_sold_review'},
  {name:'issue 714 qualifying residence occupied before year end',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'residential_home',expense_debt_purchase_method:'credit',expense_debt_purchase_total_debt:'50000000',expense_debt_purchase_cumulative_paid:'0',expense_debt_purchase_prior_recognized_percent:'0',expense_debt_purchase_asset_exists:'yes',expense_debt_purchase_used_in_muana:'yes',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income',expense_debt_purchase_home_within_shan:'yes',expense_debt_purchase_home_occupied_by_year_end:'yes'},expected:'residential_home_muana_714_review'},
  {name:'issue 714 residence outside shan does not receive automatic exemption',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'residential_home',expense_debt_purchase_method:'credit',expense_debt_purchase_total_debt:'50000000',expense_debt_purchase_cumulative_paid:'0',expense_debt_purchase_prior_recognized_percent:'0',expense_debt_purchase_asset_exists:'yes',expense_debt_purchase_used_in_muana:'yes',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income',expense_debt_purchase_home_within_shan:'no',expense_debt_purchase_home_occupied_by_year_end:'yes'},expected:'residential_home_714_conditions_not_met'},
  {name:'prior-year recognized share cannot exceed cumulative repayment share',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'garden_shop',expense_debt_purchase_method:'loan',expense_debt_purchase_total_debt:'10000000',expense_debt_purchase_cumulative_paid:'2000000',expense_debt_purchase_prior_recognized_percent:'30',expense_debt_purchase_asset_exists:'yes',expense_debt_purchase_used_in_muana:'no',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income'},expected:'debt_purchase_amounts_invalid'},
  {name:'debt purchase cumulative repayment greater than original debt is rejected',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'non_mouna',expense_debt_purchase_method:'loan',expense_debt_purchase_total_debt:'1000000',expense_debt_purchase_cumulative_paid:'1200000',expense_debt_purchase_prior_recognized_percent:'0',expense_debt_purchase_asset_exists:'yes',expense_debt_purchase_used_in_muana:'no',expense_debt_purchase_is_trade:'no',expense_debt_purchase_repayment_source:'current_income'},expected:'debt_purchase_amounts_invalid'},
  {name:'debt purchase incomplete details remain blocked',meta:{expense_category:'other',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_purchase_kind:'garden_shop'},expected:'debt_purchase_incomplete'},
  {name:'loan-funded expense source split matches total',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'3000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'500000',expense_debt_repayment_date:'1405/03/01',expense_debt_is_due:'yes',expense_debt_is_for_livelihood_or_work:'yes'},expected:'debt_rule_details_incomplete'},
  {name:'mixed funding source split matches total',meta:{expense_category:'business_cost',expense_funding_source:'mixed',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'mixed',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'1600000',expense_debt_funded_expense_amount:'1600000',expense_own_funded_expense_amount:'400000',expense_debt_paid_amount:'1000000',expense_debt_repaid_amount:'0',expense_debt_is_due:'no',expense_debt_is_for_livelihood_or_work:'yes'},expected:'debt_rule_details_incomplete'},
  {name:'mixed funding total mismatch blocked',meta:{expense_category:'business_cost',expense_funding_source:'mixed',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'mixed',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'1600000',expense_debt_funded_expense_amount:'1600000',expense_own_funded_expense_amount:'300000',expense_debt_paid_amount:'900000',expense_debt_repaid_amount:'0',expense_debt_is_due:'no',expense_debt_is_for_livelihood_or_work:'yes'},expected:'debt_amounts_inconsistent'},
  {name:'loan repayment without date blocked',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'3000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'500000',expense_debt_is_due:'yes',expense_debt_is_for_livelihood_or_work:'yes'},expected:'debt_amounts_inconsistent'},
  {name:'ordinary repair restores existing tool without adding capacity or useful life',meta:{expense_category:'business_cost',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_capital_nature:'routine_repair',expense_existing_asset_name:'دستگاه الف',expense_existing_asset_continues:'yes',expense_capacity_added:'no',expense_useful_life_extended:'no'},expected:'routine_repair_review'},
  {name:'repair that increases capacity requires capital review',meta:{expense_category:'business_cost',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_capital_nature:'routine_repair',expense_existing_asset_name:'دستگاه الف',expense_existing_asset_continues:'yes',expense_capacity_added:'yes',expense_useful_life_extended:'no'},expected:'repair_capital_effect_review'},
  {name:'capital improvement requires review',meta:{expense_category:'business_cost',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_capital_nature:'improvement'},expected:'capital_improvement_review'},
  {name:'new asset is not routine expense',meta:{expense_category:'business_cost',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_capital_nature:'new_asset'},expected:'capital_improvement_review'},
  {name:'unknown capital nature remains review',meta:{expense_category:'business_cost',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_capital_nature:'unknown'},expected:'capital_nature_unknown'},
  {name:'loan-funded expense is separately tracked without double counting',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'2000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'200000',expense_debt_repayment_date:'1405/03/01',expense_debt_is_due:'yes',expense_debt_is_for_livelihood_or_work:'yes'},expected:'debt_rule_details_incomplete'},
  {name:'unpaid debt principal is recorded but not auto deducted',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'2000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'0',expense_debt_is_due:'no',expense_debt_is_for_livelihood_or_work:'yes'},expected:'debt_rule_details_incomplete'},
  {name:'mixed funding is review-only',meta:{expense_category:'business_cost',expense_funding_source:'mixed',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'mixed',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'1000000',expense_debt_funded_expense_amount:'1000000',expense_own_funded_expense_amount:'1000000',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'0',expense_debt_is_due:'no',expense_debt_is_for_livelihood_or_work:'yes'},expected:'debt_rule_details_incomplete'},
  {name:'incomplete debt details stay incomplete',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan'},expected:'debt_funding_incomplete'},
  {name:'debt amount inconsistency is rejected',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'1000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'1200000',expense_debt_is_due:'yes',expense_debt_is_for_livelihood_or_work:'yes'},expected:'debt_amounts_inconsistent'},
  {name:'employed worker noncontinuous debt with same-year income and post-employment expense',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'3000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'0',expense_debt_is_due:'no',expense_debt_is_for_livelihood_or_work:'yes',expense_debt_worker_status:'employed',expense_debt_purpose:'business',expense_debt_continuity:'noncontinuous',expense_debt_income_same_year:'yes',expense_debt_after_work_started:'yes',expense_debt_delayed_business_income:'no',expense_debt_repayment_source:'new_income',expense_debt_exempted_asset_exists:'yes',expense_debt_exempted_asset_spent:'no'},expected:'debt_repaid_new_income_asset_retained'},
  {name:'nonemployed person noncontinuous debt without income at expense rejected',meta:{expense_category:'annual_consumable',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'2000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'0',expense_debt_is_due:'no',expense_debt_is_for_livelihood_or_work:'yes',expense_debt_worker_status:'not_employed',expense_debt_purpose:'living',expense_debt_continuity:'noncontinuous',expense_debt_income_existed_at_expense:'no',expense_debt_income_within_12_months:'yes',expense_debt_repayment_source:'exempted_same',expense_debt_exempted_asset_exists:'yes',expense_debt_exempted_asset_spent:'yes'},expected:'debt_exclusion_conditions_not_met'},
  {name:'continuous expense remains used and debt paid from exempted asset',meta:{expense_category:'annual_durable',expense_funding_source:'loan',expense_use_status:'durable',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'2000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'500000',expense_debt_repayment_date:'1405/03/01',expense_debt_is_due:'yes',expense_debt_is_for_livelihood_or_work:'yes',expense_debt_worker_status:'employed',expense_debt_purpose:'living',expense_debt_continuity:'continuous',expense_debt_continuous_still_utility:'yes',expense_debt_repayment_source:'exempted_same',expense_debt_exempted_asset_exists:'yes',expense_debt_exempted_asset_spent:'yes'},expected:'debt_repaid_from_exempted_asset'},
  {name:'new loan replacing old debt remains outstanding',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'2000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'2000000',expense_debt_repayment_date:'1405/04/01',expense_debt_is_due:'yes',expense_debt_is_for_livelihood_or_work:'yes',expense_debt_worker_status:'employed',expense_debt_purpose:'business',expense_debt_continuity:'noncontinuous',expense_debt_income_same_year:'yes',expense_debt_after_work_started:'yes',expense_debt_delayed_business_income:'no',expense_debt_repayment_source:'new_loan',expense_debt_exempted_asset_exists:'yes'},expected:'debt_replaced_by_new_loan'},
  {name:'nonemployed noncontinuous debt after twelve months is not excluded',meta:{expense_category:'annual_consumable',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1404/01/01',expense_debt_amount:'2000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'0',expense_debt_is_due:'no',expense_debt_is_for_livelihood_or_work:'yes',expense_debt_worker_status:'not_employed',expense_debt_purpose:'living',expense_debt_continuity:'noncontinuous',expense_debt_income_existed_at_expense:'yes',expense_debt_income_within_12_months:'no',expense_debt_repayment_source:'exempted_same',expense_debt_exempted_asset_exists:'yes',expense_debt_exempted_asset_spent:'yes'},expected:'debt_exclusion_conditions_not_met'},
  {name:'new income repayment with exempted asset retained is separately flagged',meta:{expense_category:'annual_durable',expense_funding_source:'loan',expense_use_status:'durable',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'2000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'500000',expense_debt_repayment_date:'1405/03/01',expense_debt_is_due:'yes',expense_debt_is_for_livelihood_or_work:'yes',expense_debt_worker_status:'employed',expense_debt_purpose:'living',expense_debt_continuity:'continuous',expense_debt_continuous_still_utility:'yes',expense_debt_repayment_source:'new_income',expense_debt_exempted_asset_exists:'yes',expense_debt_exempted_asset_spent:'no'},expected:'debt_repaid_new_income_asset_retained'},
  {name:'delayed business income debt uses issue 709 review path',meta:{expense_category:'business_cost',expense_funding_source:'loan',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_debt_source_detail:'loan',expense_debt_contract_date:'1405/01/01',expense_debt_amount:'2000000',expense_debt_funded_expense_amount:'2000000',expense_own_funded_expense_amount:'0',expense_debt_paid_amount:'2000000',expense_debt_repaid_amount:'0',expense_debt_is_due:'no',expense_debt_is_for_livelihood_or_work:'yes',expense_debt_worker_status:'employed',expense_debt_purpose:'business',expense_debt_continuity:'noncontinuous',expense_debt_delayed_business_income:'yes',expense_debt_repayment_source:'new_income',expense_debt_exempted_asset_exists:'yes',expense_debt_exempted_asset_spent:'no'},expected:'delayed_business_income_debt_review'},
  {name:'business wages/current income consumed',meta:{expense_category:'business_cost',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_residual_asset:'no'},expected:'candidate_direct_cost'},
  {name:'business cost with residual asset',meta:{expense_category:'business_cost',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_residual_asset:'yes'},expected:'capital_or_residual_benefit_review'},
  {name:'business cost residual unknown',meta:{expense_category:'business_cost',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01'},expected:'business_cost_residual_review'},
  {name:'taxed money',meta:{expense_category:'annual_consumable',expense_funding_source:'taxed_money',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01'},expected:'not_deductible_from_current_income'},
  {name:'prior-year untaxed income',meta:{expense_category:'annual_consumable',expense_funding_source:'old_untaxed_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01'},expected:'legacy_review'},
  {name:'unlawful',meta:{expense_category:'annual_consumable',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'no',expense_within_shan:'yes',expense_date:'1405/02/01'},expected:'not_qualifying'},
  {name:'extravagant/over shan',meta:{expense_category:'annual_consumable',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'no',expense_date:'1405/02/01'},expected:'not_qualifying'},
  {name:'ordinary annual consumable',meta:{expense_category:'annual_consumable',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01'},expected:'consumable_remainder_review'},
  {name:'unused durable',meta:{expense_category:'annual_durable',expense_funding_source:'current_income',expense_use_status:'no',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01'},expected:'unused_durable_exception_review'},
  {name:'durable item',meta:{expense_category:'annual_durable',expense_funding_source:'current_income',expense_use_status:'durable',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01'},expected:'durable_review'},
  {name:'uncertain shan',meta:{expense_category:'annual_consumable',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'unknown',expense_date:'1405/02/01'},expected:'review'},
  {name:'missing information',meta:{expense_category:'business_cost'},expected:'incomplete'},
  {name:'603 remainder has no financial value',meta:{expense_category:'annual_consumable',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_remaining_value:'no',expense_minimum_pack:'yes'},expected:'remainder_without_value'},
  {name:'603 minimum market unit',meta:{expense_category:'annual_consumable',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_remaining_value:'yes',expense_minimum_pack:'yes'},expected:'minimum_market_unit_remainder'},
  {name:'603 valuable excess remainder',meta:{expense_category:'annual_consumable',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_remaining_value:'yes',expense_minimum_pack:'no'},expected:'valuable_excess_remainder'},
  {name:'603 unknown remainder value',meta:{expense_category:'annual_consumable',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_minimum_pack:'yes'},expected:'consumable_remainder_review'},
  {name:'605 customary early preparation exception',meta:{expense_category:'annual_durable',expense_funding_source:'current_income',expense_use_status:'no',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_pre_need_customary:'yes',expense_future_haraj:'no'},expected:'unused_durable_exception_candidate'},
  {name:'605 future hardship exception',meta:{expense_category:'annual_durable',expense_funding_source:'current_income',expense_use_status:'no',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_pre_need_customary:'no',expense_future_haraj:'yes'},expected:'unused_durable_exception_candidate'},
  {name:'605 no exception',meta:{expense_category:'annual_durable',expense_funding_source:'current_income',expense_use_status:'no',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_pre_need_customary:'no',expense_future_haraj:'no'},expected:'unused_durable_not_exempt_candidate'},
  {name:'605 exception answers missing',meta:{expense_category:'annual_durable',expense_funding_source:'current_income',expense_use_status:'no',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01'},expected:'unused_durable_exception_review'},
  {name:'597 depreciation of taxed business tool with use evidence',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'taxed',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'5000000',expense_depreciation_evidence:'دفتر حسابداری و گزارش کارکرد',expense_asset_use_scope:'business_only',expense_business_share_percent:'100',expense_shared_activity_count:'1',expense_asset_activity:'کسب',expense_allocation_basis:'usage_log'},expected:'candidate_taxed_or_inherited_tool_depreciation'},
  {name:'597 depreciation of inherited business tool',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'inheritance',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'250000',expense_depreciation_evidence:'گزارش فنی',expense_asset_use_scope:'business_only',expense_business_share_percent:'100',expense_shared_activity_count:'1',expense_asset_activity:'کسب',expense_allocation_basis:'usage_log'},expected:'candidate_taxed_or_inherited_tool_depreciation'},
  {name:'597 depreciation asset is itself taxed property',meta:{expense_category:'business_depreciation',expense_funding_source:'taxed_money',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'taxed',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'5000000',expense_depreciation_evidence:'دفتر حسابداری',expense_asset_use_scope:'business_only',expense_business_share_percent:'100',expense_shared_activity_count:'1',expense_asset_activity:'کسب',expense_allocation_basis:'usage_log'},expected:'candidate_taxed_or_inherited_tool_depreciation'},
  {name:'597 market price decline is not use depreciation',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'taxed',expense_asset_income_use:'yes',expense_depreciation_cause:'market',expense_depreciation_amount:'5000000',expense_depreciation_evidence:'قیمت بازار',expense_asset_use_scope:'business_only',expense_business_share_percent:'100',expense_shared_activity_count:'1',expense_asset_activity:'کسب',expense_allocation_basis:'usage_log'},expected:'depreciation_not_qualified'},
  {name:'597 asset bought from current income not covered by this depreciation rule',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'other',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'5000000',expense_depreciation_evidence:'دفتر حسابداری',expense_asset_use_scope:'business_only',expense_business_share_percent:'100',expense_shared_activity_count:'1',expense_asset_activity:'کسب',expense_allocation_basis:'usage_log'},expected:'depreciation_not_qualified'},
  {name:'597 missing depreciation evidence remains incomplete',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'taxed',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'5000000'},expected:'depreciation_incomplete'},
{name:'597 mixed personal and business use remains allocation review',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'taxed',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'5000000',expense_depreciation_evidence:'دفتر کارکرد',expense_asset_use_scope:'mixed',expense_business_share_percent:'60',expense_shared_activity_count:'1',expense_asset_activity:'کارگاه',expense_allocation_basis:'working_hours'},expected:'mixed_use_allocation_review'},
  {name:'597 personal-only tool is not business depreciation',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'taxed',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'5000000',expense_depreciation_evidence:'گزارش',expense_asset_use_scope:'personal_only',expense_business_share_percent:'0',expense_shared_activity_count:'1',expense_asset_activity:'شخصی',expense_allocation_basis:'usage_log'},expected:'depreciation_not_business_use'},
  {name:'597 multiple business activities require separate allocation',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'inheritance',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'250000',expense_depreciation_evidence:'دفتر',expense_asset_use_scope:'business_only',expense_business_share_percent:'100',expense_shared_activity_count:'2',expense_asset_activity:'دو فعالیت',expense_allocation_basis:'accounting_report'},expected:'multi_activity_allocation_review'},
  {name:'597 business-only single activity remains candidate, never deduction',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'taxed',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'100000',expense_depreciation_evidence:'دفتر',expense_asset_use_scope:'business_only',expense_business_share_percent:'100',expense_shared_activity_count:'1',expense_asset_activity:'فروشگاه',expense_allocation_basis:'usage_log'},expected:'candidate_taxed_or_inherited_tool_depreciation'},
  {name:'597 missing allocation basis remains incomplete',meta:{expense_category:'business_depreciation',expense_funding_source:'current_income',expense_use_status:'yes',expense_lawful:'yes',expense_within_shan:'yes',expense_date:'1405/02/01',expense_asset_source:'taxed',expense_asset_income_use:'yes',expense_depreciation_cause:'use',expense_depreciation_amount:'100000',expense_depreciation_evidence:'دفتر',expense_asset_use_scope:'business_only',expense_business_share_percent:'100',expense_shared_activity_count:'1',expense_asset_activity:'فروشگاه'},expected:'depreciation_incomplete'}
];
for (const c of expenseAuditCases) {
  const auditCtx={Number,Math,String};
  vm.runInNewContext(ledgerSource+'\nthis.out=khomsAuditExpenseRule({id:"case",type:"expense",amount:2000000,meta:'+JSON.stringify(c.meta)+'});',auditCtx);
  assert.equal(auditCtx.out.status,c.expected,'Expense audit case failed: '+c.name);
  assert.equal(auditCtx.out.deductionApplied,false,'No expense case may be auto-deducted: '+c.name);
}
const ledgerContext = { Number, String, Math };
vm.runInNewContext(ledgerSource + '\nthis.out=khomsBuildIncomeLedger({fiscalProfile:"non_employed"},[{id:"a",type:"income",amount:120},{id:"b",type:"income",amount:80},{id:"e",type:"expense",amount:20}]);', ledgerContext);
assert.equal(ledgerContext.out.groups.length, 2, 'Non-employed income entries must remain separate periods');
assert.equal(ledgerContext.out.groups[0].incomeTotal, 120, 'Ledger must preserve informational income total');
assert.equal(ledgerContext.out.unresolved.length, 1, 'Unlinked expense must remain unresolved');

assert.equal(ledgerContext.out.calculationApplied, false, 'Ledger must not apply amounts to khums calculation');
vm.runInNewContext(ledgerSource + '\nthis.out=khomsBuildIncomeLedger({fiscalProfile:"employed"},[{id:"salary",type:"income",amount:1000,incomeKind:"business"},{id:"rent",type:"expense",amount:120,linkedIncomeId:"salary"}]);', ledgerContext);
assert.equal(ledgerContext.out.linkedExpenseCount, 1, 'A valid linked expense must be counted in the ledger');
assert.equal(ledgerContext.out.groups[0].expenseTotal, 120, 'Linked expense total must appear in its informational group');
assert.equal(ledgerContext.out.unresolved.length, 1, 'Linked expense must still require separate religious qualification review');
assert.equal(ledgerContext.out.calculationApplied, false, 'Linked expense must never be automatically deducted');
vm.runInNewContext(ledgerSource + '\nthis.out=khomsBuildIncomeLedger({fiscalProfile:"employed"},[{id:"salary",type:"income",amount:1000,incomeKind:"business"},{id:"e",type:"business_expense",amount:100,linkedIncomeId:"salary",meta:{expense_category:"business_cost",expense_funding_source:"current_income",expense_use_status:"yes",expense_lawful:"yes",expense_within_shan:"yes",expense_date:"1405/02/01",expense_residual_asset:"no"}}]);', ledgerContext);
assert(ledgerContext.out.unresolved[0].reason.includes('candidate_direct_cost'), 'Fully documented business costs must remain candidates pending rule-level confirmation');
assert.equal(ledgerContext.out.calculationApplied, false, 'Documented expenses must not be deducted automatically');
assert.equal(ledgerContext.out.expenseAudits[0].status, 'candidate_direct_cost', 'Direct business cost must be identified as a candidate, not final deduction');
assert.equal(ledgerContext.out.expenseAudits[0].deductionApplied, false, 'Rule audit must never apply deduction');
assert(html.includes('بررسی هزینه‌ها با پرسش‌های ثبت‌شده'), 'Plain-language expense review must be visible in calculation results');
assert(html.includes('function applyPlainLanguageLabels(root)') && html.includes("['مؤونه','هزینه‌های معمول زندگی یا کار']") && html.includes("['غیرمستمر','موردی']"), 'Plain-language display translation must cover technical wording');
assert(html.includes('برای جلوگیری از حساب دوباره'), 'Prior-year debt share must be clearly explained in plain Persian');


vm.runInNewContext(ledgerSource + '\nthis.out=khomsBuildIncomeLedger({fiscalProfile:"multiple_businesses"},[{id:"a",type:"income",amount:10,incomeKind:"business",incomeBusinessLine:"الف"}]);', ledgerContext);
assert.equal(ledgerContext.out.groups[0].reviewRequired, true, 'Multiple-business grouping must require independent review');

// Expense qualification questionnaire is persisted, editable, and conservative.
assert(html.includes('function expenseReviewFieldsHtml()'), 'Expense qualification fields must render');
for (const id of ['m_expense_category','m_expense_funding','m_expense_used','m_expense_lawful','m_expense_shan','m_expense_date','m_expense_residual_asset','m_expense_remaining_value','m_expense_minimum_pack','m_expense_pre_need_customary','m_expense_future_haraj']) assert(html.includes(id), 'Missing expense review field: '+id);
for (const id of ['m_expense_asset_source','m_expense_asset_income_use','m_expense_depreciation_cause','m_expense_depreciation_amount','m_expense_depreciation_evidence']) assert(html.includes(id), 'Missing depreciation review field: '+id);
assert(html.includes('expense_funding_source'), 'Expense funding source must be persisted');
assert(html.includes('claim_matured_income_lent_to_shia') || html.includes('استثنای قرض دادن درآمدی که خمس آن مستقر شده'), 'Claim issue 716 exception must be visibly identified for separate review');
assert(html.includes('m_claim_matured_income_lent_to_shia') && html.includes('claim_matured_income_lent_to_shia'), 'Claim issue 716 exception must be editable and persisted');
assert(html.includes('function khomsAuditExpenseRule(item)') && html.includes('deductionApplied:false'), 'Expense qualification must remain non-final');
assert(html.includes("expense: ['expense-qualification'], business_expense: ['expense-qualification']"), 'Expense questions must only appear for expense entries');
assert(html.includes("'expense_category':'m_expense_category'"), 'Expense answers must be restored during edit');
assert(html.includes("'expense_residual_asset':'m_expense_residual_asset'"), 'Issue 597 residual asset answer must be restored during edit');
assert(html.includes("'expense_remaining_value':'m_expense_remaining_value'"), 'Issue 603 answers must be restored during edit');
assert(html.includes("'expense_pre_need_customary':'m_expense_pre_need_customary'"), 'Issue 605 answers must be restored during edit');
assert(html.includes('مسئله ۵۹۷') && html.includes('مسئله ۶۰۳') && html.includes('مسئله ۶۰۵'), 'New rule explanations must be visible');
assert(html.includes("'expense_depreciation_amount':'m_expense_depreciation_amount'"), 'Depreciation amount must be restored during edit');
assert(html.includes('candidate_taxed_or_inherited_tool_depreciation') && html.includes('deductionApplied:false'), 'Depreciation must remain a candidate and never be auto-deducted');
for (const id of ['m_expense_asset_use_scope','m_expense_business_share_percent','m_expense_shared_activity_count','m_expense_asset_activity','m_expense_allocation_basis']) assert(html.includes(id), 'Missing mixed-use allocation field: '+id);
for (const key of ['expense_asset_use_scope','expense_business_share_percent','expense_shared_activity_count','expense_asset_activity','expense_allocation_basis']) assert(html.includes("'"+key+"':'m_"+key+"'"), 'Mixed-use field must be persisted and restored: '+key);
assert(html.includes('mixed_use_allocation_review') && html.includes('multi_activity_allocation_review') && html.includes('deductionApplied:false'), 'Mixed-use and multi-activity depreciation must remain review-only');
for (const id of ['m_expense_debt_purchase_kind','m_expense_debt_purchase_method','m_expense_debt_purchase_total_debt','m_expense_debt_purchase_cumulative_paid','m_expense_debt_purchase_prior_recognized_percent','m_expense_debt_purchase_asset_exists','m_expense_debt_purchase_used_in_muana','m_expense_debt_purchase_is_trade','m_expense_debt_purchase_repayment_source','m_expense_debt_purchase_home_within_shan','m_expense_debt_purchase_home_occupied_by_year_end']) assert(html.includes(id), 'Missing 712-714 field: '+id);
for (const key of ['expense_debt_purchase_kind','expense_debt_purchase_method','expense_debt_purchase_total_debt','expense_debt_purchase_cumulative_paid','expense_debt_purchase_prior_recognized_percent','expense_debt_purchase_asset_exists','expense_debt_purchase_used_in_muana','expense_debt_purchase_is_trade','expense_debt_purchase_repayment_source','expense_debt_purchase_home_within_shan','expense_debt_purchase_home_occupied_by_year_end']) assert(html.includes("'"+key+"':'m_"+key+"'"), '712-714 field must persist and restore: '+key);
assert(html.includes('function khomsAuditDebtPurchaseRule(item)') && html.includes('deductionApplied:false') && html.includes('garden_shop_partial_or_full_payment_713_review'), '712-714 debt purchase audit must remain review-only');
for (const id of ['m_expense_debt_worker_status','m_expense_debt_purpose','m_expense_debt_continuity','m_expense_debt_income_same_year','m_expense_debt_income_existed_at_expense','m_expense_debt_income_within_12_months','m_expense_debt_after_work_started','m_expense_debt_delayed_business_income','m_expense_debt_continuous_still_utility','m_expense_debt_repayment_source','m_expense_debt_exempted_asset_exists','m_expense_debt_exempted_asset_spent','m_expense_capital_nature','m_expense_existing_asset_name','m_expense_existing_asset_continues','m_expense_capacity_added','m_expense_useful_life_extended','m_expense_debt_source_detail','m_expense_debt_contract_date','m_expense_debt_amount','m_expense_debt_funded_expense_amount','m_expense_own_funded_expense_amount','m_expense_debt_paid_amount','m_expense_debt_repaid_amount','m_expense_debt_repayment_date','m_expense_debt_is_due','m_expense_debt_is_for_livelihood_or_work']) assert(html.includes(id), 'Missing repair/capital/debt field: '+id);
for (const key of ['expense_debt_worker_status','expense_debt_purpose','expense_debt_continuity','expense_debt_income_same_year','expense_debt_income_existed_at_expense','expense_debt_income_within_12_months','expense_debt_after_work_started','expense_debt_delayed_business_income','expense_debt_continuous_still_utility','expense_debt_repayment_source','expense_debt_exempted_asset_exists','expense_debt_exempted_asset_spent','expense_capital_nature','expense_existing_asset_name','expense_existing_asset_continues','expense_capacity_added','expense_useful_life_extended','expense_debt_source_detail','expense_debt_contract_date','expense_debt_amount','expense_debt_funded_expense_amount','expense_own_funded_expense_amount','expense_debt_paid_amount','expense_debt_repaid_amount','expense_debt_repayment_date','expense_debt_is_due','expense_debt_is_for_livelihood_or_work']) assert(html.includes("'"+key+"':'m_"+key+"'"), 'Repair/capital/debt field must persist and restore: '+key);
assert(html.includes('routine_repair_review') && html.includes('capital_improvement_review') && html.includes('debt_rule_details_incomplete') && html.includes('deductionApplied:false'), 'Repair, capital and debt statuses must remain review-only');



assert(html.includes('function khomsAuditPriorYearLinks(person,currentYear)'), 'Prior-year audit missing');
assert(html.includes('function priorYearTrackingHtml(person,currentYear)'), 'Prior-year tracking UI missing');
assert(html.includes("'prior_review_status':'m_prior_review_status'"), 'Prior-year answers must persist');
assert(html.includes('priorYearUnresolvedCount: priorYearAudit.unresolved.length'), 'Prior-year audit must be in calculation report');
const priorSrc=html.slice(html.indexOf('function khomsAuditPriorYearLinks'),html.indexOf('function currentDateInCalendar'));
const priorCtx={String,Number,Array};
vm.runInNewContext(priorSrc+'\nthis.out=khomsAuditPriorYearLinks({years:[{id:"old",title:"۱۴۰۴",items:[{id:"asset-1"}]}]},{id:"new",items:[{id:"now",meta:{prior_review_status:"yes",prior_item_reference:"۱۴۰۴::asset-1",prior_year_title:"۱۴۰۴",prior_recognized_amount:"1000",current_review_amount:"500"}}]});',priorCtx);
assert.equal(priorCtx.out.unresolved.length,0,'Valid prior-year reference should pass');
vm.runInNewContext(priorSrc+'\nthis.out=khomsAuditPriorYearLinks({years:[{id:"old",title:"۱۴۰۴",items:[]}]},{id:"new",items:[{id:"a",meta:{prior_review_status:"yes",prior_item_reference:"x",prior_year_title:"۱۴۰۴",prior_recognized_amount:"100",current_review_amount:"50"}},{id:"b",meta:{prior_review_status:"yes",prior_item_reference:"x",prior_year_title:"۱۴۰۴",prior_recognized_amount:"100",current_review_amount:"50"}}]});',priorCtx);
assert(priorCtx.out.duplicateReferences.includes('x'),'Duplicate previous-year reference must be detected');
vm.runInNewContext(priorSrc+'\nthis.out=khomsAuditPriorYearLinks({years:[{id:"old",title:"۱۴۰۴",items:[]}]},{id:"new",items:[{id:"a",meta:{prior_review_status:"yes",prior_item_reference:"x",prior_year_title:"۱۴۰۴",prior_recognized_amount:"100",current_review_amount:"150"}}]});',priorCtx);
assert(priorCtx.out.unresolved.some(x=>x.reason.includes('بیشتر')),'Higher current-year amount must be reviewed');
vm.runInNewContext(priorSrc+'\nthis.out=khomsAuditPriorYearLinks({years:[{id:"old",title:"۱۴۰۴",items:[]}]},{id:"new",items:[{id:"a",meta:{prior_review_status:"yes",prior_item_reference:"x",prior_year_title:"۱۴۰۴",prior_recognized_amount:"",current_review_amount:"0"}}]});',priorCtx);
assert(priorCtx.out.unresolved.length>0,'Blank prior amount must require review');
vm.runInNewContext(priorSrc+'\nthis.out=khomsAuditPriorYearLinks({years:[{id:"old",title:"۱۴۰۴",items:[]}]},{id:"new",items:[{id:"a",meta:{prior_review_status:"yes",prior_item_reference:"x",prior_year_title:"۱۴۰۳",prior_recognized_amount:"10",current_review_amount:"0"}}]});',priorCtx);
assert(priorCtx.out.unresolved.some(x=>x.reason.includes('پیدا نشد')),'Missing prior year must require review');
assert(html.includes('priorYearTrackingHtml(p,y)'), 'Prior-year section must be displayed in item form');


// Backup schema migration: accept the previous schema without losing profile or financial data,
// write new backups as schema 2, and reject unsupported future schemas.
assert(html.includes('function migrateBackupPayload(payload)'), 'Backup migration function missing');
assert(html.includes("payload.schemaVersion = 2"), 'Legacy backup must migrate to schema 2');
assert(html.includes('schemaVersion: 2'), 'New backups must use schema 2');
const migrationStart = html.indexOf('function migrateBackupPayload');
const migrationEnd = html.indexOf('function parseBackup', migrationStart);
const migrationSource = html.slice(migrationStart, migrationEnd);
const migrationCtx = { Number, Error };
vm.runInNewContext(migrationSource + '\nthis.migrated=migrateBackupPayload({app:"khoms-manager",schemaVersion:1,data:{db:{people:[{id:"p1",years:[{id:"y1",items:[{id:"i1",meta:{custom:"keep"}}]}]}]},priceDb:[]},customField:"preserve"});', migrationCtx);
assert.equal(migrationCtx.migrated.schemaVersion, 2, 'Schema 1 must migrate to schema 2');
assert.equal(migrationCtx.migrated.data.db.people[0].years[0].items[0].meta.custom, 'keep', 'Migration must preserve nested financial metadata');
assert.equal(migrationCtx.migrated.customField, 'preserve', 'Migration must preserve unknown top-level fields');
assert.equal(migrationCtx.migrated.migrationInfo.from, 1, 'Migration origin must be recorded');
vm.runInNewContext(migrationSource + '\nthis.migrated=migrateBackupPayload({app:"khoms-manager",schemaVersion:2,data:{db:{people:[]},priceDb:[]}});', migrationCtx);
assert.equal(migrationCtx.migrated.schemaVersion, 2, 'Schema 2 migration must be idempotent');
assert.throws(() => vm.runInNewContext(migrationSource + '\nmigrateBackupPayload({app:"khoms-manager",schemaVersion:3});', migrationCtx), /newer|پشتیبانی/);

// Backup restore must verify read-after-write and preserve old data when verification fails.
assert(html.includes('localStorage.getItem(KEY) !== nextDb || localStorage.getItem(PRICE_KEY) !== nextPrices'), 'Restore must verify both data stores after writing');
assert(html.includes('var rollbackVerified = localStorage.getItem(KEY) === oldDb && localStorage.getItem(PRICE_KEY) === oldPrices'), 'Restore rollback must be verified');
assert(html.includes('اگر ذخیره کامل نشود، برنامه تلاش می‌کند اطلاعات قبلی را برگرداند'), 'Restore warning must explain replacement and rollback in plain language');
const applyStart = html.indexOf('function applyBackup(text)');
const applyEnd = html.indexOf('\nfunction restoreBackupText', applyStart);
const applySource = html.slice(applyStart, applyEnd);
function runRestoreSimulation(readBackMismatch) {
  const store = new Map([['khoms_db_v1', '{"people":[{"id":"old"}]}'], ['khoms_price_db_v1', '[]']]);
  const writes = [];
  const localStorage = {
    getItem(k) { return store.has(k) ? store.get(k) : null; },
    setItem(k,v) { writes.push([k,v]); store.set(k, String(v)); if (readBackMismatch && k === 'khoms_db_v1' && writes.filter(x=>x[0]===k).length===1) store.set(k, 'corrupt'); },
    removeItem(k) { store.delete(k); }
  };
  const originalDb = { people: [{ id: 'old' }] }, originalPrices = [];
  const ctx = { parseBackup: () => ({ data: { db: { people: [{ id: 'new' }] }, priceDb: [] } }), confirm: () => true, localStorage,
    KEY: 'khoms_db_v1', PRICE_KEY: 'khoms_price_db_v1', db: originalDb, priceDb: originalPrices, storageLoadErrors: [],
    alert: msg => { ctx.alertMessage = msg; }, nav() {}, JSON };
  vm.runInNewContext(applySource + '\napplyBackup("valid");', ctx);
  return {ctx, store, originalDb, originalPrices};
}
const goodRestore = runRestoreSimulation(false);
assert.equal(goodRestore.ctx.db.people[0].id, 'new', 'Verified restore must replace the in-memory data');
const badRestore = runRestoreSimulation(true);
assert.equal(badRestore.ctx.db.people[0].id, 'old', 'Failed read-back must not replace in-memory data');
assert.equal(badRestore.store.get('khoms_db_v1'), '{"people":[{"id":"old"}]}', 'Failed restore must roll back old stored data');
assert(badRestore.ctx.alertMessage.includes('اطلاعات قبلی حفظ شد'), 'Failed restore must report verified rollback');

console.log('Khoms 2.38.19 source validation: PASS');
