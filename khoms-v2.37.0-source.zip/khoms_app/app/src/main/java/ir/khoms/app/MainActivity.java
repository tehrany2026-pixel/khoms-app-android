package ir.khoms.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import java.util.ArrayList;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 4107;
    private WebView web;
    private SpeechRecognizer recognizer;
    private String pendingLanguage = "fa-IR";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("file:///android_asset/")) return false;
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl())); } catch (Exception ignored) { }
                }
                return true;
            }
        });
        web.addJavascriptInterface(new VoiceBridge(), "AndroidKhoms");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private class VoiceBridge {
        @JavascriptInterface public void startSpeech(String language) {
            pendingLanguage = (language == null || language.trim().isEmpty()) ? "fa-IR" : language;
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
                } else {
                    beginSpeech();
                }
            });
        }
    }

    private void beginSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendSpeechResult("", "سرویس تشخیص گفتار روی این گوشی در دسترس نیست. می‌توانید از میکروفن صفحه‌کلید استفاده کنید.");
            return;
        }
        try {
            if (recognizer != null) { recognizer.destroy(); recognizer = null; }
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) {
                    String msg = error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS
                        ? "اجازه استفاده از میکروفن داده نشد."
                        : "تشخیص گفتار انجام نشد. اتصال یا بسته زبان فارسی سرویس گفتار را بررسی کنید یا از میکروفن صفحه‌کلید استفاده کنید.";
                    sendSpeechResult("", msg);
                    destroyRecognizer();
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    sendSpeechResult(matches != null && !matches.isEmpty() ? matches.get(0) : "", null);
                    destroyRecognizer();
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, pendingLanguage);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, pendingLanguage);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            recognizer.startListening(intent);
        } catch (Exception ex) {
            sendSpeechResult("", "فعال‌سازی تشخیص گفتار ممکن نشد. از میکروفن صفحه‌کلید گوشی استفاده کنید.");
            destroyRecognizer();
        }
    }

    private void sendSpeechResult(String text, String error) {
        if (web == null) return;
        String js = "window.onKhomsSpeechResult && window.onKhomsSpeechResult(" + JSONObject.quote(text == null ? "" : text) + "," + (error == null ? "null" : JSONObject.quote(error)) + ");";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginSpeech();
            else sendSpeechResult("", "برای استفاده از میکروفن باید اجازه ضبط صدا را بدهید.");
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        destroyRecognizer();
        if (web != null) { web.removeJavascriptInterface("AndroidKhoms"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
