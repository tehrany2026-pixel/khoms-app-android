@echo off
setlocal
set "HERE=%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%HERE%run_local_server.py"
  if not errorlevel 1 exit /b 0
  echo اجرای سرور محلی ناموفق بود.
  pause
  exit /b 1
)
where python >nul 2>nul
if %errorlevel%==0 (
  python "%HERE%run_local_server.py"
  if not errorlevel 1 exit /b 0
  echo اجرای سرور محلی ناموفق بود.
  pause
  exit /b 1
)
echo هشدار: Python 3 نصب نیست؛ HTML را مستقيماً باز می‌کنیم.
echo برای ذخیره‌سازی پایدارتر دسکتاپ، Python 3 را نصب و دوباره اجرا کنید.
start "مدیریت خمس" "%HERE%index.html"
