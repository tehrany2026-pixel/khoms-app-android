#!/usr/bin/env python3
"""Launch the offline desktop app on a stable loopback origin for reliable localStorage."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import os
import webbrowser

HOST = "127.0.0.1"
PORT = int(os.environ.get("KHOMS_PORT", "8765"))
PORT_TRIES = 20
HTML = (Path(__file__).resolve().parent / "index.html").read_bytes()

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path not in ("/", "/index.html", "/health"):
            self.send_error(404)
            return
        if self.path == "/health":
            body = b"ok"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
        else:
            body = HTML
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        print("[Khoms offline] " + (fmt % args))

def create_server():
    """Bind only to loopback, trying nearby ports if the preferred one is busy."""
    last_error = None
    for candidate in range(PORT, PORT + PORT_TRIES):
        try:
            return HTTPServer((HOST, candidate), Handler), candidate
        except OSError as exc:
            last_error = exc
    raise SystemExit(
        f"هیچ پورتی از {PORT} تا {PORT + PORT_TRIES - 1} در دسترس نیست. "
        f"برنامه‌های دیگر را ببندید یا متغیر KHOMS_PORT را تنظیم کنید. جزئیات: {last_error}"
    )

if __name__ == "__main__":
    server, actual_port = create_server()
    url = f"http://{HOST}:{actual_port}/"
    print(f"نرم‌افزار خمس به‌صورت آفلاین اجرا می‌شود: {url}")
    print(f"سرور فقط روی همین دستگاه (127.0.0.1:{actual_port}) گوش می‌دهد؛ برای بستن برنامه Ctrl+C را بزنید.")
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nبرنامه بسته شد.")
    finally:
        server.server_close()
