#!/bin/sh
# Double-click this file in Finder to launch the offline desktop app.
set -eu
APP_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if command -v python3 >/dev/null 2>&1; then
  exec python3 "$APP_DIR/run_local_server.py"
fi
printf '%s\n' 'Python 3 پیدا نشد؛ فایل HTML مستقیماً باز می‌شود.' 'در این حالت ذخیره‌سازی محلی به مرورگر وابسته است؛ پشتیبان بگیرید.' >&2
if command -v open >/dev/null 2>&1; then exec open "$APP_DIR/index.html"; fi
printf '%s\n' 'فایل desktop/index.html را در مرورگر باز کنید.' >&2
exit 1
