#!/bin/sh
set -eu
rm -f "$HOME/.local/share/applications/khoms-manager.desktop"
rm -rf "$HOME/.local/share/khoms-manager"
printf 'فایل‌های برنامه حذف شدند. داده‌های ذخیره‌شده در مرورگر ممکن است باقی بمانند.
'
