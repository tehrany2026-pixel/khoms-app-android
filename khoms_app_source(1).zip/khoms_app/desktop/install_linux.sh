#!/bin/sh
set -eu
SOURCE_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
DEST="$HOME/.local/share/khoms-manager"
APPS="$HOME/.local/share/applications"
mkdir -p "$DEST" "$APPS"
# Copy only project files needed for the portable desktop launcher and documentation.
rm -rf "$DEST/desktop" "$DEST/rules" "$DEST/README.md" "$DEST/FINAL_DELIVERY_FA.md"
cp -R "$SOURCE_DIR/desktop" "$DEST/desktop"
[ ! -d "$SOURCE_DIR/rules" ] || cp -R "$SOURCE_DIR/rules" "$DEST/rules"
[ ! -f "$SOURCE_DIR/README.md" ] || cp "$SOURCE_DIR/README.md" "$DEST/README.md"
cat > "$APPS/khoms-manager.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=مدیریت و محاسبه خمس
Comment=محاسبه آفلاین و نگهداری سوابق خمس
Exec=$DEST/desktop/run_linux.sh
Icon=$DEST/desktop/icon.svg
Terminal=false
Categories=Office;Finance;
EOF
chmod +x "$DEST/desktop/run_linux.sh" "$APPS/khoms-manager.desktop"
printf 'نصب انجام شد. از منوی برنامه‌ها «مدیریت و محاسبه خمس» را اجرا کنید.
'
printf 'مسیر برنامه: %s
' "$DEST"
printf 'اطلاعات برنامه در حافظه مرورگر ذخیره می‌شود؛ پیش از پاک‌کردن داده‌ها پشتیبان بگیرید.
'
