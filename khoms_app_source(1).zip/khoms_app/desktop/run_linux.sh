#!/bin/sh
set -eu
APP_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -f "$APP_DIR/run_local_server.py" ] && command -v python3 >/dev/null 2>&1; then
  exec python3 "$APP_DIR/run_local_server.py"
fi
printf '%s\n' 'هشدار: Python 3 در دسترس نیست؛ اجرای مستقیم فایل HTML را امتحان می‌کنیم.' 'در این حالت ذخیره‌سازی محلی به مرورگر وابسته است؛ پیش از پاک‌کردن داده‌های مرورگر نسخه پشتیبان بگیرید.' >&2
HTML="$APP_DIR/index.html"
if command -v xdg-open >/dev/null 2>&1; then exec xdg-open "$HTML"; fi
if command -v open >/dev/null 2>&1; then exec open "$HTML"; fi
echo 'فایل desktop/index.html را در مرورگر باز کنید.' >&2
exit 1
