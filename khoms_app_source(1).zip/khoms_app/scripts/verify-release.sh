#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
node scripts/build-compat.cjs
node --test tests/regression.test.cjs
node --check extracted.js
python -m json.tool rules/sources/sistani_sources.json >/dev/null
node scripts/validate-marja-packs.cjs
for f in rules/marja_packs/*.json; do python -m json.tool "$f" >/dev/null; done
cmp -s desktop/index.html android/app/src/main/assets/index.html
printf 'OK: Android/Desktop HTML همسان است.\n'
grep -q "versionCode 34; versionName '2.34.0'" android/app/build.gradle
grep -q "com.android.application' version '8.6.1'" android/build.gradle
grep -q 'نسخه ۲٫۳۴' desktop/index.html
grep -q 'def create_server()' desktop/run_local_server.py
test -x desktop/run_macos.command
grep -q 'function emailBackup()' desktop/index.html
grep -q 'function saveUsingPreferredMode()' desktop/index.html
grep -q 'backupMode' desktop/index.html
grep -q 'BACKUP_MODE_KEY' desktop/index.html
grep -q 'minSdk 21' android/app/build.gradle
grep -q '127.0.0.1' desktop/run_local_server.py
grep -q 'compat-css' desktop/index.html
grep -q 'Array.prototype.find' desktop/index.html
grep -q 'public void shareBackup(String json)' android/app/src/main/java/com/example/khoms/MainActivity.java
node scripts/check-android-build.cjs
grep -q 'androidx.core.content.FileProvider' android/app/src/main/AndroidManifest.xml
printf 'OK: نسخه ۲٫۳۴، ES5، Android API 21، لانچر آفلاین دسکتاپ و پشتیبان‌گیری بررسی شدند.\n'
if command -v gradle >/dev/null 2>&1; then
  printf 'Gradle موجود است: '
  gradle --version | sed -n '1,8p'
else
  printf 'BLOCKED: Gradle نصب نیست؛ APK در این محیط ساخته نمی‌شود.\n'
fi
if [[ -n "${ANDROID_HOME:-}" || -n "${ANDROID_SDK_ROOT:-}" ]]; then
  printf 'Android SDK environment variable is configured.\n'
else
  printf 'BLOCKED: Android SDK environment variable تنظیم نشده است.\n'
fi
