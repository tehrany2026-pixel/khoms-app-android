#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if ! command -v gradle >/dev/null 2>&1; then
  echo "خطا: Gradle پیدا نشد. Gradle 8.9 را نصب کنید یا از Android Studio استفاده کنید." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "خطا: ANDROID_HOME یا ANDROID_SDK_ROOT تنظیم نشده است." >&2
  exit 3
fi
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT}}"
if [[ ! -d "$SDK/platforms/android-35" ]]; then
  echo "خطا: Android SDK Platform 35 نصب نیست. از SDK Manager نصبش کنید." >&2
  exit 4
fi
npm run verify
gradle --no-daemon -p android assembleDebug
APK="$ROOT/android/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -s "$APK" ]]; then
  echo "خطا: ساخت پایان یافت اما APK در مسیر مورد انتظار پیدا نشد." >&2
  exit 5
fi
echo "APK ساخته شد: $APK"
