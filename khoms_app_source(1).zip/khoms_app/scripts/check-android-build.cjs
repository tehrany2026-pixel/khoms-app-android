const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const workflow = read('.github/workflows/android-apk.yml');
const gradle = read('android/app/build.gradle');
const settings = read('android/settings.gradle');
const manifest = read('android/app/src/main/AndroidManifest.xml');
const checks = [
  ['workflow can be run manually', /workflow_dispatch:/],
  ['Java 17 configured', /java-version:\s*'17'/],
  ['Android platform 35 installed', /platforms;android-35/],
  ['Gradle 8.9 configured', /gradle-version:\s*'8\.9'/],
  ['debug APK build task configured', /assembleDebug/],
  ['APK artifact uploaded', /actions\/upload-artifact@v4/],
  ['current Android version is 34', /versionCode 34; versionName '2\.34\.0'/],
  ['minimum Android API is 21', /minSdk 21/],
  ['Android application module included', /include ':app'/],
  ['launcher activity exported', /android:exported="true"/],
  ['internet permission not required by app manifest', !/android\.permission\.INTERNET/.test(manifest)],
];
let failed = 0;
for (const [name, pattern] of checks) {
  const ok = typeof pattern === 'boolean' ? pattern : pattern.test(name.includes('current Android') || name.includes('minimum Android') ? gradle : name.includes('module included') ? settings : name.includes('launcher activity') || name.includes('internet permission') ? manifest : workflow);
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
  if (!ok) failed++;
}
if (failed) process.exitCode = 1;
else console.log(`OK: ${checks.length} Android build configuration checks passed.`);
