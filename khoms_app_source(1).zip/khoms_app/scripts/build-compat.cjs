const fs = require('node:fs');
const path = require('node:path');
let ts;
try { ts = require('typescript'); }
catch (first) {
  const candidates = [process.env.TYPESCRIPT_PATH, '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js'].filter(Boolean);
  for (const candidate of candidates) { try { ts = require(candidate); break; } catch (_) {} }
  if (!ts) throw new Error('TypeScript لازم است؛ اجرا کنید: npm install --save-dev typescript');
}
const root = path.join(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'extracted.js'), 'utf8');
const compiled = ts.transpileModule(source, {
  compilerOptions: { target: ts.ScriptTarget.ES5, module: ts.ModuleKind.ES2015, downlevelIteration: true, removeComments: false },
  reportDiagnostics: true
});
const diagnostics = (compiled.diagnostics || []).filter(d => d.category === ts.DiagnosticCategory.Error);
if (diagnostics.length) throw new Error(ts.formatDiagnosticsWithColorAndContext(diagnostics, { getCurrentDirectory: process.cwd, getCanonicalFileName: x => x, getNewLine: () => '\n' }));
const polyfills = `/* Compatibility helpers for older Android System WebView and desktop browsers. */
(function(){
  if (!Array.prototype.includes) Array.prototype.includes = function(search, from){ var a=Object(this), n=a.length>>>0, i=Number(from)||0; if(i<0)i=Math.max(n+i,0); for(;i<n;i++)if(a[i]===search || (a[i]!==a[i] && search!==search))return true; return false; };
  if (!Array.prototype.find) Array.prototype.find = function(fn, self){ if(this==null)throw new TypeError('Array.prototype.find called on null'); var a=Object(this), n=a.length>>>0; for(var i=0;i<n;i++)if(fn.call(self,a[i],i,a))return a[i]; return undefined; };
  if (!String.prototype.startsWith) String.prototype.startsWith = function(search, pos){ pos=pos||0; return this.substr(pos, String(search).length)===String(search); };
  if (!Number.isFinite) Number.isFinite = function(v){ return typeof v==='number' && isFinite(v); };
  if (!Array.from) Array.from = function(value, mapFn, thisArg){ var out=[], i=0, n=Number(value && value.length)||0; for(;i<n;i++)out.push(mapFn?mapFn.call(thisArg,value[i],i):value[i]); return out; };
})();
`;
const bundle = polyfills + compiled.outputText;
if (/=>|\?\.|\?\?|\basync\s+function|`/.test(bundle)) throw new Error('خروجی سازگار هنوز شامل نحو جدید JavaScript است');
const htmlPath = path.join(root, 'desktop/index.html');
let html = fs.readFileSync(htmlPath, 'utf8');
const open = html.indexOf('<script>');
const close = html.indexOf('</script>', open);
if (open < 0 || close < 0) throw new Error('بلوک اسکریپت داخل HTML پیدا نشد');
html = html.slice(0, open + '<script>'.length) + bundle + html.slice(close);
fs.writeFileSync(htmlPath, html);
fs.copyFileSync(htmlPath, path.join(root, 'android/app/src/main/assets/index.html'));
console.log(`OK: اسکریپت به ES5 تبدیل شد (${source.length} → ${bundle.length} نویسه) و HTML اندروید/دسکتاپ همسان شد.`);
