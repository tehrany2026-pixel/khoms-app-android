const fs = require('node:fs');
const path = require('node:path');
const dir = path.join(__dirname, '../rules/marja_packs');
const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
const ids = new Set();
if (manifest.schema_version !== 1 || !Array.isArray(manifest.pack_files)) throw new Error('ساختار manifest نامعتبر است');
for (const file of manifest.pack_files) {
  const p = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
  for (const key of ['pack_id','marja_name','status','runtime_rule_source','rules','inherit_from','note']) {
    if (!(key in p)) throw new Error(`${file}: فیلد ${key} موجود نیست`);
  }
  if (ids.has(p.pack_id)) throw new Error(`شناسه بسته تکراری: ${p.pack_id}`);
  ids.add(p.pack_id);
  if (!Array.isArray(p.rules)) throw new Error(`${file}: rules باید آرایه باشد`);
  if (p.inherit_from !== null) throw new Error(`${file}: ارث‌بری قواعد ممنوع است`);
  if (p.runtime_rule_source === 'none' && p.rules.some(r => r.active === true)) throw new Error(`${file}: قاعده فعال بدون موتور منبع`);
  if (p.status === 'pending_verification' && (p.runtime_rule_source !== 'none' || p.rules.some(r => r.active === true))) throw new Error(`${file}: بسته تأییدنشده نباید قاعده فعال داشته باشد`);
  if (p.status === 'verified_partial' && (!p.source_index || !p.official_source_url || p.runtime_rule_source !== 'embedded_runtime')) throw new Error(`${file}: بسته جزئی منبع runtime و رسمی لازم دارد`);
}
if (ids.size !== manifest.profile_count || ids.size !== manifest.pack_files.length) throw new Error('تعداد بسته‌ها با manifest سازگار نیست');
console.log(`OK: ${ids.size} بسته مستقل؛ بدون ارث‌بری؛ بسته‌های تأییدنشده غیرفعال هستند.`);
