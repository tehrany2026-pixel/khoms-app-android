const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const html = fs.readFileSync(path.join(__dirname, '../desktop/index.html'), 'utf8');
const source = fs.readFileSync(path.join(__dirname, '../extracted.js'), 'utf8');
const match = html.match(/<script>([\s\S]*?)<\/script>/i);
assert.ok(match, 'application script exists');

function makeApp(options = {}) {
  const store = new Map(Object.entries(options.storage || {}));
  const alerts = [];
  const elements = new Map();
  let failNextPriceWrite = false;
  const localStorage = {
    getItem(k) { return store.has(k) ? store.get(k) : null; },
    setItem(k, v) {
      if (k === 'khoms_prices_v05' && failNextPriceWrite) {
        failNextPriceWrite = false;
        throw new Error('simulated storage failure');
      }
      store.set(k, String(v));
    },
    removeItem(k) { store.delete(k); }
  };
  const appElement = { innerHTML: '' };
  const appendedElements = [];
  const document = { getElementById(id) { if (id === 'app') return appElement; if (!elements.has(id)) elements.set(id, { value: '', innerHTML: '', focus(){}, select(){}, appendChild(){}, remove(){} }); return elements.get(id); }, execCommand(){return true}, createElement(){return {style:{},click(){},remove(){}}}, body:{appendChild(el){appendedElements.push(el)}} };
  const context = vm.createContext({
    console, localStorage, document,
    alert: (m) => alerts.push(String(m)),
    confirm: () => options.confirm ?? true,
    prompt: () => options.promptResult === undefined ? null : options.promptResult,
    Blob: class Blob {}, URL: { createObjectURL(){return ''}, revokeObjectURL(){} },
    setTimeout: () => 0,
  });
  vm.runInContext(match[1], context, { timeout: 5000 });
  return { context, store, alerts, elements, appendedElements, failPriceWrite() { failNextPriceWrite = true; } };
}

function setupYear(app, items) {
  vm.runInContext(`db={people:[{id:'p1',name:'آزمون',code:'',marja:'آیت‌الله سیستانی',years:[{id:'y1',title:'۱۴۰۵',marja:'آیت‌الله سیستانی',start:'2026-01-01',items:${JSON.stringify(items)},result:null,status:'آزمون'}]}]}; state={page:'year',personId:'p1',yearId:'y1'};`, app.context);
}

test('خروجی اجرایی از نحو ES5 استفاده می‌کند و polyfillهای لازم را دارد', () => {
  assert.doesNotMatch(match[1], /=>|\?\.|\?\?|\basync\s+function|`/);
  assert.match(match[1], /Array\.prototype\.find/);
  assert.match(match[1], /Number\.isFinite/);
});

test('حداقل Android روی API 21 است و جهت صفحه قفل نشده است', () => {
  const gradle = fs.readFileSync(path.join(__dirname, '../android/app/build.gradle'), 'utf8');
  const manifest = fs.readFileSync(path.join(__dirname, '../android/app/src/main/AndroidManifest.xml'), 'utf8');
  assert.match(gradle, /minSdk 21/);
  assert.doesNotMatch(manifest, /screenOrientation=/);
});

test('لانچر دسکتاپ از مبدأ محلی پایدار و فقط loopback استفاده می‌کند', () => {
  const server = fs.readFileSync(path.join(__dirname, '../desktop/run_local_server.py'), 'utf8');
  assert.match(server, /HOST = "127\.0\.0\.1"/);
  assert.match(server, /PORT = int\(os\.environ\.get\(\"KHOMS_PORT\", \"8765\"\)\)/);
  assert.match(server, /PORT_TRIES = 20/);
  assert.match(server, /def create_server\(\)/);
  assert.match(server, /self\.path not in \("\/", \"\/index\.html\", \"\/health\"\)/);
  assert.match(server, /server\.serve_forever\(\)/);
});

test('لانچر macOS موجود است و در نبود Python به HTML برمی‌گردد', () => {
  const launcher = fs.readFileSync(path.join(__dirname, '../desktop/run_macos.command'), 'utf8');
  assert.match(launcher, /python3/);
  assert.match(launcher, /open .*index\.html/);
  assert.match(launcher, /run_local_server\.py/);
});

test('سرور دسکتاپ در صورت اشغال بودن پورت، پورت بعدی loopback را امتحان می‌کند', () => {
  const server = fs.readFileSync(path.join(__dirname, '../desktop/run_local_server.py'), 'utf8');
  assert.match(server, /for candidate in range\(PORT, PORT \+ PORT_TRIES\)/);
  assert.match(server, /HTTPServer\(\(HOST, candidate\), Handler\)/);
  assert.match(server, /127\.0\.0\.1/);
});

test('درآمد خالص مثبت با نرخ ۲۰ درصد محاسبه می‌شود', () => {
  const a = makeApp();
  setupYear(a, [{id:'i1',type:'income',amount:1000,marketValue:0,meta:{}},{id:'e1',type:'expense',amount:200,marketValue:0,meta:{}}]);
  vm.runInContext('calcYear()', a.context);
  const result = vm.runInContext('db.people[0].years[0].result', a.context);
  assert.equal(result.base, 800);
  assert.equal(result.annualKhoms, 160);
  assert.equal(result.khoms, 160);
});

test('هزینه بیشتر از درآمد، خمس منفی تولید نمی‌کند و هشدار می‌دهد', () => {
  const a = makeApp();
  setupYear(a, [{id:'i1',type:'income',amount:100,marketValue:0,meta:{}},{id:'e1',type:'expense',amount:1000,marketValue:0,meta:{}}]);
  vm.runInContext('calcYear()', a.context);
  const result = vm.runInContext('db.people[0].years[0].result', a.context);
  assert.equal(result.base, 0);
  assert.equal(result.annualKhoms, 0);
  assert.equal(result.khoms, 0);
  assert.ok(result.warnings.some(w => w.includes('خمس منفی')));
});

test('مبلغ منفی به‌جای پایه مشمول، از محاسبه قطعی خارج می‌شود', () => {
  const a = makeApp();
  setupYear(a, [{id:'i1',type:'income',amount:-500,marketValue:0,meta:{}}]);
  vm.runInContext('calcYear()', a.context);
  const result = vm.runInContext('db.people[0].years[0].result', a.context);
  assert.equal(result.khoms, 0);
  assert.equal(result.excluded.length, 1);
});

test('پشتیبان معتبر پذیرفته می‌شود', () => {
  const a = makeApp();
  const valid = JSON.stringify({app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'p',name:'الف',marja:'آیت‌الله سیستانی',years:[{id:'y',items:[]}]}]},priceDb:[]}});
  assert.equal(vm.runInContext(`parseBackup(${JSON.stringify(valid)}).data.db.people.length`, a.context), 1);
});

test('پشتیبان ناقص و ساختار سال نامعتبر رد می‌شود', () => {
  const a = makeApp();
  assert.throws(() => vm.runInContext(`parseBackup('not-json')`, a.context), /JSON/);
  const invalid = JSON.stringify({app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'p',name:'الف',marja:'آیت‌الله سیستانی',years:[{id:'y'}]}]},priceDb:[]}});
  assert.throws(() => vm.runInContext(`parseBackup(${JSON.stringify(invalid)})`, a.context), /ساختار سال/);
});

test('شکست ذخیره‌سازی هنگام بازیابی، وضعیت حافظه برنامه را عوض نمی‌کند', () => {
  const a = makeApp();
  vm.runInContext(`db={people:[{id:'old',name:'قدیمی',code:'',marja:'آیت‌الله سیستانی',years:[]}]}; priceDb=[]; save();`, a.context);
  const incoming = JSON.stringify({app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'new',name:'جدید',code:'',marja:'آیت‌الله سیستانی',years:[]}]},priceDb:[]}});
  a.failPriceWrite();
  vm.runInContext(`applyBackup(${JSON.stringify(incoming)})`, a.context);
  assert.equal(vm.runInContext('db.people[0].id', a.context), 'old');
  assert.ok(a.alerts.some(m => m.includes('ذخیره پشتیبان کامل نشد')));
});


test('پرداخت جزئی قسط ثبت می‌شود و مانده همان قسط قابل پرداخت می‌ماند', () => {
  const a = makeApp({promptResult:'25'});
  setupYear(a, []);
  vm.runInContext(`db.people[0].years[0].result={khoms:100,annualKhoms:100,specialKhoms:0,base:500,specialBase:0,rate:.2,lines:[],specialLines:[],excluded:[],warnings:[],ruleVersion:'test',marja:'آیت‌الله سیستانی',calculatedAt:''}; db.people[0].years[0].installmentPlan={id:'pl',total:100,count:2,intervalDays:30,startDate:'2026-01-01',installments:[{id:'a',amount:50,dueDate:'2026-01-01',status:'unpaid',paidAmount:0},{id:'b',amount:50,dueDate:'2026-01-31',status:'unpaid',paidAmount:0}]};`, a.context);
  vm.runInContext("payInstallment('a')", a.context);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].paidAmount", a.context),25);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].status", a.context),'partial');
});

test('پرداخت یک قسط بیش از مانده همان قسط پذیرفته نمی‌شود', () => {
  const a = makeApp({promptResult:'75'});
  setupYear(a, []);
  vm.runInContext(`db.people[0].years[0].result={khoms:100,annualKhoms:100,specialKhoms:0,base:500,specialBase:0,rate:.2,lines:[],specialLines:[],excluded:[],warnings:[],ruleVersion:'test',marja:'آیت‌الله سیستانی',calculatedAt:''}; db.people[0].years[0].installmentPlan={id:'pl',total:100,count:2,intervalDays:30,startDate:'2026-01-01',installments:[{id:'a',amount:50,dueDate:'2026-01-01',status:'unpaid',paidAmount:0},{id:'b',amount:50,dueDate:'2026-01-31',status:'unpaid',paidAmount:0}]};`, a.context);
  vm.runInContext("payInstallment('a')", a.context);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].paidAmount", a.context),0);
  assert.ok(a.alerts.some(m=>m.includes('بیشتر است')));
});

test('قیمت منفی یا صفر ذخیره نمی‌شود', () => {
  const a = makeApp();
  a.elements.set('pq',{value:'-2'}); a.elements.set('pp',{value:'10'}); a.elements.set('pt',{value:'طلا'}); a.elements.set('pu',{value:'گرم'}); a.elements.set('ps',{value:'آزمون'}); a.elements.set('pd',{value:'2026-10-09T12:00'});
  vm.runInContext('savePrice()', a.context);
  assert.equal(vm.runInContext('priceDb.length', a.context),0);
  assert.ok(a.alerts.some(m=>m.includes('مثبت')));
});

test('پشتیبان با قیمت منفی رد می‌شود', () => {
  const a = makeApp();
  const bad = JSON.stringify({app:'khoms-manager',schemaVersion:1,data:{db:{people:[]},priceDb:[{qty:-1,unitPrice:2,total:-2}]}});
  assert.throws(()=>vm.runInContext(`parseBackup(${JSON.stringify(bad)})`,a.context),/سابقه قیمت/);
});


test('دو پرداخت جزئی می‌تواند یک قسط را دقیقاً تسویه کند', () => {
  const a = makeApp({promptResult:'25'});
  setupYear(a, []);
  vm.runInContext(`db.people[0].years[0].result={khoms:100,annualKhoms:100,specialKhoms:0,base:500,specialBase:0,rate:.2,lines:[],specialLines:[],excluded:[],warnings:[],ruleVersion:'test',marja:'آیت‌الله سیستانی',calculatedAt:''}; db.people[0].years[0].installmentPlan={id:'pl',total:100,count:2,intervalDays:30,startDate:'2026-01-01',installments:[{id:'a',amount:50,dueDate:'2026-01-01',status:'unpaid',paidAmount:0},{id:'b',amount:50,dueDate:'2026-01-31',status:'unpaid',paidAmount:0}]};`, a.context);
  vm.runInContext("payInstallment('a')", a.context);
  vm.runInContext("payInstallment('a')", a.context);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].paidAmount", a.context),50);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].status", a.context),'paid');
});

test('جمع اقساط ساخته‌شده دقیقاً برابر مبلغ کل است', () => {
  const a = makeApp();
  setupYear(a, []);
  vm.runInContext("db.people[0].years[0].result={khoms:101,annualKhoms:101,specialKhoms:0,base:505,specialBase:0,rate:.2,lines:[],specialLines:[],excluded:[],warnings:[],ruleVersion:'test',marja:'آیت‌الله سیستانی',calculatedAt:''}", a.context);
  a.elements.set('icount',{value:'4'}); a.elements.set('idays',{value:'30'});
  vm.runInContext('createInstallments()', a.context);
  assert.equal(vm.runInContext('db.people[0].years[0].installmentPlan.installments.reduce((s,x)=>s+x.amount,0)',a.context),101);
});


test('پشتیبان چند فرد و چند سال، نتیجه‌ها و تاریخچه اقساط را حفظ می‌کند', () => {
  const a = makeApp();
  vm.runInContext(`db={people:[
    {id:'p1',name:'الف',code:'A',marja:'آیت‌الله سیستانی',years:[
      {id:'y1',title:'۱۴۰۴',marja:'آیت‌الله سیستانی',items:[{id:'i1',type:'income',amount:100}],result:{khoms:20},installmentPlan:{id:'pl1',total:20,count:2,intervalDays:30,startDate:'2025-01-01',installments:[{id:'in1',amount:10,dueDate:'2025-01-01',paidAmount:4,status:'partial',paidDate:'2025-01-02'},{id:'in2',amount:10,dueDate:'2025-01-31',paidAmount:0,status:'unpaid'}]}}
    ]},
    {id:'p2',name:'ب',code:'B',marja:'آیت‌الله سیستانی',years:[{id:'y2',title:'۱۴۰۵',marja:'آیت‌الله سیستانی',items:[{id:'i2',type:'income',amount:200}],result:{khoms:40}}]}
  ]}; priceDb=[{id:'price1',type:'طلا',qty:1,unit:'گرم',unitPrice:500,total:500,source:'آزمون',date:'2026-01-01'}];`, a.context);
  const payload = vm.runInContext('JSON.stringify(backupPayload())', a.context);
  const restored = vm.runInContext(`parseBackup(${JSON.stringify(payload)})`, a.context);
  assert.equal(restored.data.db.people.length, 2);
  assert.equal(restored.data.db.people[0].years.length, 1);
  assert.equal(restored.data.db.people[0].years[0].installmentPlan.installments[0].paidAmount, 4);
  assert.equal(restored.data.db.people[1].years[0].result.khoms, 40);
  assert.equal(restored.data.priceDb[0].total, 500);
});

test('پشتیبان قدیمی که فقط وضعیت قسط تسویه‌شده دارد به‌صورت سازگار خوانده می‌شود', () => {
  const a = makeApp();
  const legacy = {app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'p',name:'الف',marja:'آیت‌الله سیستانی',years:[{id:'y',title:'۱۴۰۴',items:[],installmentPlan:{id:'pl',total:10,installments:[{id:'i',amount:10,status:'paid'}]}}]}]},priceDb:[]}};
  const parsed = vm.runInContext(`parseBackup(${JSON.stringify(JSON.stringify(legacy))})`, a.context);
  assert.equal(parsed.data.db.people[0].years[0].installmentPlan.installments[0].paidAmount, 10);
  assert.equal(parsed.data.db.people[0].years[0].installmentPlan.installments[0].status, 'paid');
  assert.equal(parsed.data.db.people[0].years[0].installmentPlan.installments[0].paymentHistory.length, 1);
  assert.equal(parsed.data.db.people[0].years[0].installmentPlan.installments[0].paymentHistory[0].amount, 10);
});

test('پشتیبان با جمع اقساط ناسازگار یا شناسه پرونده تکراری رد می‌شود', () => {
  const a = makeApp();
  const badPlan = {app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'p',name:'الف',marja:'آیت‌الله سیستانی',years:[{id:'y',items:[],installmentPlan:{id:'pl',total:20,installments:[{id:'i',amount:10,status:'unpaid'}]}}]}]},priceDb:[]}};
  assert.throws(()=>vm.runInContext(`parseBackup(${JSON.stringify(JSON.stringify(badPlan))})`,a.context),/جمع مبلغ اقساط/);
  const duplicate = {app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'p',name:'الف',marja:'آیت‌الله سیستانی',years:[]},{id:'p',name:'ب',marja:'آیت‌الله سیستانی',years:[]}]},priceDb:[]}};
  assert.throws(()=>vm.runInContext(`parseBackup(${JSON.stringify(JSON.stringify(duplicate))})`,a.context),/شناسه تکراری/);
});


test('پشتیبان با شناسه تکراری در تاریخچه قیمت رد می‌شود', () => {
  const a = makeApp();
  const backup = {app:'khoms-manager',schemaVersion:1,data:{db:{people:[]},priceDb:[
    {id:'price-x',qty:1,unitPrice:10,total:10},
    {id:'price-x',qty:2,unitPrice:10,total:20}
  ]}};
  assert.throws(()=>vm.runInContext(`parseBackup(${JSON.stringify(JSON.stringify(backup))})`,a.context),/شناسه تکراری در تاریخچه قیمت/);
});

test('پشتیبان با ارزش کل ناسازگار با مقدار ضربدر قیمت واحد رد می‌شود', () => {
  const a = makeApp();
  const backup = {app:'khoms-manager',schemaVersion:1,data:{db:{people:[]},priceDb:[
    {id:'price-x',qty:2,unitPrice:10,total:19}
  ]}};
  assert.throws(()=>vm.runInContext(`parseBackup(${JSON.stringify(JSON.stringify(backup))})`,a.context),/با مقدار و قیمت واحد سازگار نیست/);
});

test('پشتیبان با سابقه قیمت محاسباتی معتبر پذیرفته می‌شود', () => {
  const a = makeApp();
  const backup = {app:'khoms-manager',schemaVersion:1,data:{db:{people:[]},priceDb:[
    {id:'price-x',qty:1.5,unitPrice:12.4,total:18.6}
  ]}};
  assert.equal(vm.runInContext(`parseBackup(${JSON.stringify(JSON.stringify(backup))}).data.priceDb[0].total`,a.context),18.6);
});


test('نسخه موبایل و دسکتاپ دقیقاً از یک HTML موتور استفاده می‌کنند', () => {
  const mobile = fs.readFileSync(path.join(__dirname, '../android/app/src/main/assets/index.html'), 'utf8');
  assert.equal(mobile, html);
});

test('نمایش حکم از پنجره داخلی استفاده می‌کند تا در WebView موبایل هم قابل دسترس باشد', () => {
  assert.match(source, /function showRule\(ruleId\).*role=\\\"dialog\\\"/);
  assert.doesNotMatch(source, /function showRule\(ruleId\).*window\.open/);
});

test('Android دسترسی file URL عمومی را می‌بندد و پیوندهای وب را به مرورگر سیستم می‌فرستد', () => {
  const java = fs.readFileSync(path.join(__dirname, '../android/app/src/main/java/com/example/khoms/MainActivity.java'), 'utf8');
  assert.match(java, /setAllowFileAccessFromFileURLs\(false\)/);
  assert.match(java, /setAllowUniversalAccessFromFileURLs\(false\)/);
  assert.match(java, /shouldOverrideUrlLoading/);
  assert.match(java, /Intent\(Intent\.ACTION_VIEW, uri\)/);
});

test('نسخه Android انتخاب فایل پشتیبان و ذخیره امن فایل JSON را به API سیستم وصل می‌کند', () => {
  const java = fs.readFileSync(path.join(__dirname, '../android/app/src/main/java/com/example/khoms/MainActivity.java'), 'utf8');
  assert.match(java, /onShowFileChooser/);
  assert.match(java, /ACTION_OPEN_DOCUMENT/);
  assert.match(java, /ACTION_CREATE_DOCUMENT/);
  assert.match(java, /@JavascriptInterface\s+public void exportBackup/);
  assert.match(java, /getContentResolver\(\)\.openOutputStream/);
  assert.match(source, /window\.KhomsBridge\.exportBackup\(payload\)/);
});

test('داده محلی خراب، برنامه را به بازیابی هدایت می‌کند و مانع نوشتن روی آن می‌شود', () => {
  const a = makeApp({storage:{khoms_v11:'{broken-json'}});
  assert.equal(vm.runInContext('state.page', a.context), 'backup');
  assert.match(a.context.document.getElementById('app').innerHTML, /بازیابی ایمن لازم است/);
  vm.runInContext('nav()', a.context);
  assert.equal(vm.runInContext('state.page', a.context), 'backup');
  assert.ok(a.alerts.length >= 0);
});

test('شماره نسخه Android و سربرگ برنامه با نسخه ۲٫۳۴ همخوان است', () => {
  const gradle = fs.readFileSync(path.join(__dirname, '../android/app/build.gradle'), 'utf8');
  assert.match(gradle, /versionCode 34/);
  assert.match(gradle, /versionName '2\.34\.0'/);
  assert.match(html, /نسخه ۲٫۳۴/);
});




test('روش ذخیره‌سازی پیش‌فرض انتخابی کاربر در حافظه تنظیمات حفظ می‌شود', () => {
  const a = makeApp();
  assert.equal(vm.runInContext('preferredBackupMode', a.context), 'file');
  vm.runInContext("setBackupMode('email')", a.context);
  assert.equal(vm.runInContext('preferredBackupMode', a.context), 'email');
  assert.equal(a.store.get('khoms_backup_mode_v1'), 'email');
  vm.runInContext("state.page='backup';app()", a.context);
  assert.match(a.context.document.getElementById('app').innerHTML, /backupMode/);
});

test('روش انتخاب‌شده برای ذخیره محلی، پرونده‌ها و تاریخچه قیمت را هر دو ذخیره می‌کند', () => {
  const a = makeApp();
  vm.runInContext("db={people:[{id:'p-save',name:'ذخیره',years:[]}]};priceDb=[{id:'price-save',qty:2,unitPrice:5,total:10}];setBackupMode('device');saveUsingPreferredMode()", a.context);
  assert.equal(JSON.parse(a.store.get('khoms_v11')).people[0].id, 'p-save');
  assert.equal(JSON.parse(a.store.get('khoms_prices_v05'))[0].id, 'price-save');
  assert.ok(a.alerts.some(m => m.includes('روی همین دستگاه ذخیره شد')));
});

test('روش ذخیره‌سازی نامعتبر به گزینه امن فایل بازمی‌گردد', () => {
  const a = makeApp();
  vm.runInContext("setBackupMode('unknown')", a.context);
  assert.equal(vm.runInContext('preferredBackupMode', a.context), 'file');
  assert.equal(a.store.get('khoms_backup_mode_v1'), 'file');
});

test('هر پرداخت جزئی در تاریخچه ثبت می‌شود و جمع تاریخچه با مانده قسط برابر می‌ماند', () => {
  const a = makeApp({promptResult:'25'});
  setupYear(a, []);
  vm.runInContext(`db.people[0].years[0].result={khoms:100,annualKhoms:100,specialKhoms:0,base:500,specialBase:0,rate:.2,lines:[],specialLines:[],excluded:[],warnings:[],ruleVersion:'test',marja:'آیت‌الله سیستانی',calculatedAt:''}; db.people[0].years[0].installmentPlan={id:'pl',total:100,count:2,intervalDays:30,startDate:'2026-01-01',installments:[{id:'a',amount:50,dueDate:'2026-01-01',status:'unpaid',paidAmount:0,paymentHistory:[]},{id:'b',amount:50,dueDate:'2026-01-31',status:'unpaid',paidAmount:0,paymentHistory:[]}]};`, a.context);
  vm.runInContext("payInstallment('a')", a.context);
  vm.runInContext("payInstallment('a')", a.context);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].paymentHistory.length", a.context), 2);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].paymentHistory.reduce((s,e)=>s+(e.type==='payment'?e.amount:-e.amount),0)", a.context), 50);
});

test('بازگردانی وضعیت قسط، سابقه پرداخت را حذف نمی‌کند و رویداد برگشت ثبت می‌شود', () => {
  const a = makeApp({promptResult:'50'});
  setupYear(a, []);
  vm.runInContext(`db.people[0].years[0].installmentPlan={id:'pl',total:50,count:1,intervalDays:30,startDate:'2026-01-01',installments:[{id:'a',amount:50,dueDate:'2026-01-01',status:'unpaid',paidAmount:0,paymentHistory:[]}]};`, a.context);
  vm.runInContext("payInstallment('a')", a.context);
  vm.runInContext("unpayInstallment('a')", a.context);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].paidAmount", a.context), 0);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].paymentHistory.length", a.context), 2);
  assert.equal(vm.runInContext("db.people[0].years[0].installmentPlan.installments[0].paymentHistory[1].type", a.context), 'reversal');
});

test('پشتیبان ناسازگار که تاریخچه پرداختش با مبلغ پرداختی نمی‌خواند رد می‌شود', () => {
  const a = makeApp();
  const bad = JSON.stringify({app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'p',name:'الف',marja:'آیت‌الله سیستانی',years:[{id:'y',items:[],installmentPlan:{id:'pl',total:10,installments:[{id:'i',amount:10,paidAmount:5,status:'partial',paymentHistory:[{type:'payment',amount:3,date:'2026-01-01'}]}]}}]}]},priceDb:[]}});
  assert.throws(()=>vm.runInContext(`parseBackup(${JSON.stringify(bad)})`,a.context),/تاریخچه پرداخت با مانده/);
});

test('پیکربندی ساخت Android برای compileSdk 35 از AGP سازگار استفاده می‌کند', () => {
  const rootBuild = fs.readFileSync(path.join(__dirname, '../android/build.gradle'), 'utf8');
  const appBuild = fs.readFileSync(path.join(__dirname, '../android/app/build.gradle'), 'utf8');
  assert.match(rootBuild, /com\.android\.application' version '8\.6\.1'/);
  assert.match(appBuild, /compileSdk 35/);
  assert.match(appBuild, /versionCode 34; versionName '2\.34\.0'/);
});

test('محاسبه snapshot ورودی‌های زمان محاسبه را حفظ می‌کند', () => {
  const a = makeApp();
  setupYear(a, [{id:'i1',type:'income',amount:1000,marketValue:0,meta:{note:'اولیه'}}]);
  vm.runInContext('calcYear()', a.context);
  assert.equal(vm.runInContext('db.people[0].years[0].result.inputSnapshot.items[0].amount', a.context), 1000);
  vm.runInContext("db.people[0].years[0].items[0].amount=1200", a.context);
  assert.equal(vm.runInContext('db.people[0].years[0].result.inputSnapshot.items[0].amount', a.context), 1000);
  const html = vm.runInContext('renderResult(db.people[0].years[0].result,db.people[0].years[0])', a.context);
  assert.ok(html.includes('snapshot قبلی'));
});

test('اختلاف مبلغ محاسبه جدید با برنامه اقساط قبلی هشدار می‌دهد و اقساط را دست‌کاری نمی‌کند', () => {
  const a = makeApp();
  const y = {result:{khoms:120},installmentPlan:{total:100,intervalDays:30,startDate:'2026-01-01',installments:[{id:'i',amount:100,dueDate:'2026-01-01',paidAmount:25,status:'partial',paymentHistory:[{type:'payment',amount:25,date:'2026-01-01'}]}]}};
  const html = vm.runInContext(`installmentSection(${JSON.stringify(y)})`, a.context);
  assert.ok(html.includes('مبلغ محاسبه فعلی با مبلغ برنامه اقساط یکسان نیست'));
  assert.equal(y.installmentPlan.installments[0].paidAmount,25);
});

test('تاریخ تقویمی برای سررسید از اجزای تاریخ محلی ساخته می‌شود', () => {
  const a = makeApp();
  assert.equal(vm.runInContext("localDateString(new Date(2026,9,9))", a.context),'2026-10-09');
});


test('تاریخچه پشتیبان برگشت بیشتر از پرداخت‌های قبلی را رد می‌کند', () => {
  const a = makeApp();
  const backup = {app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'p',name:'الف',marja:'آیت‌الله سیستانی',years:[{id:'y',items:[],installmentPlan:{id:'pl',total:100,installments:[{id:'i',amount:100,paidAmount:0,paymentHistory:[{type:'reversal',amount:10,date:'2026-10-09'},{type:'payment',amount:10,date:'2026-10-09'}]}]}}]}]},priceDb:[]}};
  assert.throws(()=>vm.runInContext(`parseBackup(${JSON.stringify(JSON.stringify(backup))})`,a.context),/برگشت از پرداخت‌های قبلی بیشتر است/);
});

test('تاریخچه پشتیبان پرداخت مرحله‌ای بیش از مبلغ قسط را رد می‌کند', () => {
  const a = makeApp();
  const backup = {app:'khoms-manager',schemaVersion:1,data:{db:{people:[{id:'p',name:'الف',marja:'آیت‌الله سیستانی',years:[{id:'y',items:[],installmentPlan:{id:'pl',total:100,installments:[{id:'i',amount:100,paidAmount:100,paymentHistory:[{type:'payment',amount:120,date:'2026-10-09'},{type:'reversal',amount:20,date:'2026-10-09'}]}]}}]}]},priceDb:[]}};
  assert.throws(()=>vm.runInContext(`parseBackup(${JSON.stringify(JSON.stringify(backup))})`,a.context),/در یک مرحله از مبلغ قسط بیشتر شده است/);
});

test('تاریخ پرداخت و برگشت از تابع تاریخ محلی استفاده می‌کند', () => {
  assert.match(source, /const paymentDate=localDateString\(new Date\(\)\)/);
  assert.match(source, /date:localDateString\(new Date\(\)\),note:'بازگردانی دستی وضعیت قسط/);
});

test('شماره نسخه Android و سربرگ برنامه با نسخه ۲٫۳۴ همخوان است', () => {
  const gradle = fs.readFileSync(path.join(__dirname, '../android/app/build.gradle'), 'utf8');
  assert.match(gradle, /versionCode 34/);
  assert.match(gradle, /versionName '2.34.0'/);
  assert.match(html, /نسخه ۲٫۳۴/);
});


test('پوسته نسخه ۲٫۳۴ برای موبایل واکنش‌گرا و دارای تمرکز قابل‌مشاهده است', () => {
  assert.match(html, /@media\(max-width:640px\)/);
  assert.match(html, /:focus-visible/);
  assert.match(html, /--brand:#176b5b/);
  assert.match(html, /border-radius:18px/);
  assert.match(html, /نسخه ۲٫۳۴ · آماده‌سازی ساخت APK · سازگاری گسترده Android و دسکتاپ · فارسی پیش‌فرض/);
});

test('صفحه اصلی داشبورد خلاصه پرونده‌ها و مسیر شروع را نشان می‌دهد', () => {
  const a = makeApp();
  const view = vm.runInContext("document.getElementById('app').innerHTML", a.context);
  assert.match(view, /خوش آمدید/);
  assert.match(view, /پرونده فردی/);
  assert.match(view, /ایجاد اولین پرونده/);
  assert.match(view, /پشتیبان‌گیری و بازیابی/);
});


test('فرم مالی فقط بخش‌های پیشرفته مرتبط با نوع قلم را نمایش می‌دهد', () => {
  const a = makeApp();
  assert.deepEqual(Array.from(vm.runInContext("decisionGroupsForType('income')", a.context)), []);
  assert.deepEqual(Array.from(vm.runInContext("decisionGroupsForType('jabr')", a.context)), ['jabr']);
  assert.deepEqual(Array.from(vm.runInContext("decisionGroupsForType('business_cross_jabr')", a.context)), ['cross-business']);
  assert.ok(vm.runInContext("decisionGroupsForType('legacy_uncertain_settlement').includes('legacy-uncertain')", a.context));
  assert.match(source, /id="it" onchange="syncDecisionSections\(\)"/);
  assert.match(source, /data-decision-group="property"/);
  assert.match(html, /\.decision-extra\[hidden\]\{display:none!important\}/);
});

test('تغییر نوع قلم، بخش‌های تخصصی نامرتبط را واقعاً پنهان می‌کند', () => {
  const a = makeApp();
  const selector = {value:'jabr'};
  const sections = ['jabr','property','cross-business'].map(group => ({
    group, hidden:false, style:{}, getAttribute(name){ return name==='data-decision-group'?this.group:null; }
  }));
  a.context.fakeSelector = selector;
  a.context.fakeSections = sections;
  vm.runInContext("document.getElementById=(id)=>id==='it'?fakeSelector:null; document.querySelectorAll=()=>fakeSections; syncDecisionSections()", a.context);
  assert.equal(sections[0].hidden, false);
  assert.equal(sections[1].hidden, true);
  assert.equal(sections[2].hidden, true);
  selector.value='property_asset';
  vm.runInContext('syncDecisionSections()', a.context);
  assert.equal(sections[0].hidden, true);
  assert.equal(sections[1].hidden, false);
});


test('رجیستری منابع، تعداد قواعد را از داده واقعی می‌خواند و وضعیت ارجاعی را فعال اعلام نمی‌کند', () => {
  const a = makeApp();
  const counts = vm.runInContext(`(()=>{const all=RULES.sistani.rules;const active=all.filter(x=>{const e=String(x.engine||'');return x.active!==false&&e!=='reference_only'&&!e.startsWith('reference_only')&&!e.startsWith('disabled')}).length;const refs=all.filter(x=>{const e=String(x.engine||'');return e==='reference_only'||e.startsWith('reference_only')||e.startsWith('disabled')||x.active===false}).length;return {total:all.length,active,refs}})()`, a.context);
  assert.equal(counts.total, vm.runInContext('RULES.sistani.rules.length', a.context));
  assert.ok(counts.active + counts.refs <= counts.total);
  assert.ok(vm.runInContext("ruleEngineStatus({active:false,engine:'decision_engine_v17'}).label", a.context).includes('غیرفعال'));
  assert.equal(vm.runInContext("ruleEngineStatus({engine:'reference_only'}).label", a.context), 'فقط ارجاع');
  assert.ok(vm.runInContext("ruleEngineStatus({engine:'decision_engine_guarded_review'}).label", a.context).includes('احتیاطی'));
});


test('پنجره منابع تعداد را پویا نشان می‌دهد و هشدار ناقص‌بودن موتور را دارد', () => {
  const a = makeApp();
  vm.runInContext('sourceRegistry()', a.context);
  assert.equal(a.appendedElements.length, 1);
  const panel = a.appendedElements[0].innerHTML;
  const total = vm.runInContext('RULES.sistani.rules.length', a.context).toLocaleString('fa-IR');
  assert.ok(panel.includes(total));
  assert.match(panel, /مدخل قواعد ثبت‌شده/);
  assert.match(panel, /به معنی تکمیل همه فروعات فقهی نیست/);
  assert.match(panel, /توضیح المسائل جامع جلد ۲/);
});


test('زبان فارسی پیش‌فرض است و فهرست زبان‌های چندزبانه و کد سفارشی دارد', () => {
  const a = makeApp();
  assert.equal(vm.runInContext("uiLanguage", a.context), 'fa');
  assert.match(html, /<html lang="fa" dir="rtl">/);
  assert.match(html, /id="uiLanguage"/);
  assert.match(html, /value="other">زبان دیگر/);
  assert.match(source, /UI_LANG_KEY='khoms_ui_language_v1'/);
});

test('تغییر زبان ذخیره می‌شود و داده‌های مالی فارسی/یونیکد را تغییر نمی‌دهد', () => {
  const a = makeApp();
  vm.runInContext("db.people=[{id:'p',name:'علی آذربایجانی',years:[]}];setUiLanguage('az')", a.context);
  assert.equal(vm.runInContext('uiLanguage', a.context), 'az');
  assert.equal(a.store.get('khoms_ui_language_v1'), 'az');
  assert.equal(vm.runInContext('db.people[0].name', a.context), 'علی آذربایجانی');
  assert.equal(vm.runInContext("localeDirection('ar')", a.context), 'rtl');
  assert.equal(vm.runInContext("localeDirection('en')", a.context), 'ltr');
});

test('بسته‌های ترجمه و قالب‌بندی عدد برای زبان انتخاب‌شده تعریف شده‌اند', () => {
  assert.match(source, /fr:\{'خوش آمدید':'Bienvenue'/);
  assert.match(source, /zh:\{'خوش آمدید':'欢迎'/);
  assert.match(source, /toLocaleString\(uiLanguage \|\| 'fa-IR'\)/);
  assert.match(source, /ترجمهٔ این زبان فعلاً جزئی است/);
});

test('پشتیبان‌گیری ایمیلی فقط با درخواست و تأیید کاربر فعال می‌شود', () => {
  assert.match(source, /onclick="emailBackup\(\)"/);
  assert.match(source, /async function emailBackup\(\)/);
  assert.match(source, /confirm\('نسخه پشتیبان شامل اطلاعات مالی خصوصی است/);
  assert.match(source, /KhomsBridge\.shareBackup\(payload\)/);
  assert.match(source, /navigator\.canShare\(\{files:\[file\]\}\)/);
  assert.match(source, /فایل JSON دانلودشده را به‌صورت پیوست اضافه کنید/);
});

test('اشتراک‌گذاری Android فایل JSON را با FileProvider به برنامه انتخابی می‌سپارد', () => {
  const java = fs.readFileSync(path.join(__dirname, '../android/app/src/main/java/com/example/khoms/MainActivity.java'), 'utf8');
  const manifest = fs.readFileSync(path.join(__dirname, '../android/app/src/main/AndroidManifest.xml'), 'utf8');
  const paths = fs.readFileSync(path.join(__dirname, '../android/app/src/main/res/xml/file_paths.xml'), 'utf8');
  assert.match(java, /public void shareBackup\(String json\)/);
  assert.match(java, /Intent\.ACTION_SEND/);
  assert.match(java, /FileProvider\.getUriForFile/);
  assert.match(java, /Intent\.EXTRA_STREAM, uri/);
  assert.match(java, /Intent\.createChooser/);
  assert.match(manifest, /androidx\.core\.content\.FileProvider/);
  assert.match(paths, /cache-path name="backup_files" path="backups\/"/);
});


test('هر مرجع صفحه مستقل دارد و فقط بسته سیستانی به عنوان جزئی فعال است', () => {
  const a = makeApp();
  assert.equal(vm.runInContext("marjaProfileFor('آیت‌الله سیستانی').id", a.context), 'sistani');
  assert.equal(vm.runInContext("marjaProfileFor('آیت‌الله خامنه‌ای').id", a.context), 'khamenei');
  assert.equal(vm.runInContext("marjaProfileFor('آیت‌الله خامنه‌ای').status", a.context), 'not_verified');
  assert.match(source, /function marjaProfilePage\(el\)/);
  assert.match(source, /مشاهده احکام و منابع همین مرجع/);
});

test('قاعده مرجع سیستانی برای مرجع دیگر بازگردانده نمی‌شود و fallback خطرناک حذف شده است', () => {
  const a = makeApp();
  assert.equal(vm.runInContext("ruleFor('آیت‌الله خامنه‌ای','income')", a.context), null);
  assert.equal(vm.runInContext("ruleFor('آیت‌الله سیستانی','income').id", a.context), 'income_profit');
  assert.doesNotMatch(source, /ruleFor\(y\.marja,x\.type\)\|\|RULES\.sistani\.rules/);
});

test('محاسبه سال بر اساس مرجع همان سال مسدود می‌شود، حتی اگر مرجع پرونده سیستانی باشد', () => {
  const a = makeApp();
  vm.runInContext("db={people:[{id:'p1',name:'آزمون',marja:'آیت‌الله سیستانی',years:[{id:'y1',title:'۱۴۰۵',marja:'آیت‌الله خامنه‌ای',items:[{type:'income',amount:1000,marketValue:0,meta:{}}],result:null,status:'آزمون'}]}]}; state={page:'year',personId:'p1',yearId:'y1'}; calcYear()", a.context);
  assert.match(a.alerts.join(' '), /هیچ قاعده‌ای از مرجع دیگر اعمال نشد/);
  assert.equal(vm.runInContext('db.people[0].years[0].result', a.context), null);
});

test('مرجع دیگر را می‌توان با نام دقیق ثبت کرد و پروفایل مستقل می‌گیرد', () => {
  const a = makeApp();
  assert.match(source, /نام دقیق مرجع تقلید/);
  assert.match(source, /toggleCustomMarja/);
  assert.equal(vm.runInContext("marjaProfileFor('مرجع آقای الف').id", a.context), 'other');
});


test('شناسه مرجع دقیق است؛ نامی که فقط شامل «سیستانی» است قاعده نمی‌گیرد', () => {
  const a = makeApp();
  assert.equal(vm.runInContext("ruleFor('مرجع سیستانی دیگر','income')", a.context), null);
  assert.equal(vm.runInContext("ruleFor('آیت‌الله سیستانی','income').id", a.context), 'income_profit');
});

test('برای همه مراجع فایل بسته مستقل وجود دارد و هیچ بسته‌ای از مرجع دیگر ارث نمی‌برد', () => {
  const dir = path.join(__dirname, '../rules/marja_packs');
  const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
  assert.equal(manifest.profile_count, 11);
  const ids = new Set();
  for (const file of manifest.pack_files) {
    const pack = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
    assert.ok(pack.pack_id && pack.marja_name && pack.status);
    assert.equal(pack.inherit_from, null);
    assert.ok(Array.isArray(pack.rules));
    assert.ok(!ids.has(pack.pack_id));
    ids.add(pack.pack_id);
    if (pack.status === 'pending_verification') {
      assert.equal(pack.runtime_rule_source, 'none');
      assert.equal(pack.rules.filter(r => r.active === true).length, 0);
    }
  }
  assert.equal(ids.size, 11);
});

test('اعتبارسنج بسته‌های مستقل مرجع بدون خطا اجرا می‌شود', () => {
  const { execFileSync } = require('node:child_process');
  const output = execFileSync(process.execPath, [path.join(__dirname, '../scripts/validate-marja-packs.cjs')], {encoding:'utf8'});
  assert.match(output, /11 بسته مستقل/);
});


test('شناسه و نام بسته‌های مستقل دقیقاً با پروفایل‌های داخل برنامه همسان است', () => {
  const a = makeApp();
  const runtime = JSON.parse(JSON.stringify(vm.runInContext('MARJA_PROFILES.map(p=>({id:p.id,name:p.name}))', a.context)));
  const dir = path.join(__dirname, '../rules/marja_packs');
  const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'manifest.json'), 'utf8'));
  const packs = manifest.pack_files.map(f => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')));
  const normalizedPacks = packs.map(p=>({id:p.pack_id,name:p.marja_name})).sort((x,y)=>x.id.localeCompare(y.id));
  const normalizedRuntime = runtime.sort((x,y)=>x.id.localeCompare(y.id));
  assert.deepEqual(normalizedPacks, normalizedRuntime);
});


test('مسیر ساخت APK اندروید در CI دارای محیط و خروجی قابل‌بررسی است', () => {
  const workflow = fs.readFileSync(path.join(__dirname, '../.github/workflows/android-apk.yml'), 'utf8');
  const checker = fs.readFileSync(path.join(__dirname, '../scripts/check-android-build.cjs'), 'utf8');
  assert.match(workflow, /workflow_dispatch:/);
  assert.match(workflow, /java-version:\s*'17'/);
  assert.match(workflow, /platforms;android-35/);
  assert.match(workflow, /gradle-version:\s*'8\.9'/);
  assert.match(workflow, /assembleDebug/);
  assert.match(workflow, /actions\/upload-artifact@v4/);
  assert.match(checker, /current Android version is 34/);
  const localBuilder = fs.readFileSync(path.join(__dirname, '../scripts/build-android-apk.sh'), 'utf8');
  assert.match(localBuilder, /ANDROID_HOME/);
  assert.match(localBuilder, /assembleDebug/);
  assert.match(localBuilder, /app-debug\.apk/);
});
