# راهنمای ساخت APK اندروید — نسخه ۲٫۳۴

## پیش‌نیازها

- Java 17
- Node.js 22 و npm
- Gradle 8.9
- Android SDK Platform 35 و Build Tools 35.0.0
- متغیر `ANDROID_HOME` یا `ANDROID_SDK_ROOT` که به مسیر Android SDK اشاره کند

## ساخت در Linux یا macOS

از ریشه پروژه اجرا کنید:

```bash
npm install
npm run build:android
```

اسکریپت ابتدا وجود Gradle و SDK را بررسی می‌کند، سپس بررسی انتشار و آزمون‌های برنامه را اجرا می‌کند و در پایان APK آزمایشی را می‌سازد.

مسیر خروجی:

`android/app/build/outputs/apk/debug/app-debug.apk`

## ساخت در Windows

در PowerShell از ریشه پروژه:

```powershell
npm install
npm run verify
gradle --no-daemon -p android assembleDebug
```

اگر Gradle در PATH نیست، پروژه `android` را در Android Studio باز کنید و از پنجره Gradle، وظیفه `:app:assembleDebug` را اجرا کنید. Android SDK Platform 35 باید از SDK Manager نصب شده باشد.

## ساخت خودکار در GitHub Actions

فایل `.github/workflows/android-apk.yml` به پروژه اضافه شده است. پس از قرارگرفتن پروژه در مخزن GitHub، از تب **Actions** گردش‌کار **Build Android APK** را انتخاب و **Run workflow** را اجرا کنید. پس از موفقیت، فایل `khoms-android-debug-v2.34` را از بخش Artifacts همان اجرا دریافت کنید. Artifact پس از ۱۴ روز منقضی می‌شود.

## هشدار انتشار

این گردش‌کار APK نوع debug می‌سازد؛ برای انتشار عمومی باید کلید امضای release، حفاظت از کلید، سیاست حریم خصوصی و آزمون روی دستگاه واقعی تنظیم شود. ساخت موفق نیز به‌تنهایی سازگاری با همه نسخه‌های Android یا WebView را ثابت نمی‌کند.
